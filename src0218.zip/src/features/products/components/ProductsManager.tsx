// src/features/products/components/ProductsManager.tsx
import { useMemo, useRef, useState } from "react"

import ProductRowActions from "@/features/products/components/ProductRowActions"

import { AppButton } from "@/components/app/AppButton"
import { AppCard } from "@/components/app/AppCard"
import { AppInput } from "@/components/app/AppInput"
import { AppSwitch } from "@/components/app/AppSwitch"
import { AppSelect } from "@/components/app/AppSelect"
import { AppBadge } from "@/components/app/AppBadge"

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

import { useAppData } from "@/features/core/useAppData"
import { ConfirmDialog } from "@/components/shared/ConfirmDialog"
import { toast } from "@/lib/toast"
import { EmptyState } from "@/components/shared/EmptyState"
import { Skeleton } from "@/components/shared/Skeleton"
import { ErrorState } from "@/components/shared/ErrorState"

const ITEMS_PER_PAGE = 20

// ✅ 폭을 줄여서 860px 내에서 최대한 스크롤 없게
const COL = {
  category: "w-[110px]",
  name: "w-[190px]", 
  price: "w-[80px]",
  sku: "w-[120px]",
  barcode: "w-[140px]",
  status: "w-[160px]",
  actions: "w-[72px]",
} as const

export default function ProductsManager() {
  const a = useAppData()

  const [productListCategory, setProductListCategory] = useState<string>("all")
  const [productListPage, setProductListPage] = useState<number>(1)
  const [query, setQuery] = useState<string>("")
  const [sort, setSort] = useState<{
    key: "createdAt" | "name" | "category" | "active" | "price"
    dir: "asc" | "desc"
  }>({ key: "createdAt", dir: "desc" })

  const [deleteProductId, setDeleteProductId] = useState<string>("")
  const [deleteProductName, setDeleteProductName] = useState<string>("")
  const [deleteCategoryName, setDeleteCategoryName] = useState<string>("")

  // 편집 값(로컬)
  const editPriceRef = useRef<number>(0)
  const editSkuRef = useRef<string>("")
  const editBarcodeRef = useRef<string>("")

  const [editingPrice, setEditingPrice] = useState<number>(0)
  const [editingSku, setEditingSku] = useState<string>("")
  const [editingBarcode, setEditingBarcode] = useState<string>("")

  const sortedProducts = useMemo(() => {
    const arr = [...a.data.products]
    const dir = sort.dir === "asc" ? 1 : -1

    arr.sort((x, y) => {
      // ✅ 판매중(활성) 우선: OFF는 항상 아래로
const ax = Boolean(x.active)
const ay = Boolean(y.active)
if (ax !== ay) return (ax ? -1 : 1)
      if (sort.key === "createdAt") {
        return ((x.createdAt ?? 0) - (y.createdAt ?? 0)) * dir
      }

      if (sort.key === "price") {
        const px = Number(x.price ?? 0)
        const py = Number(y.price ?? 0)
        if (px === py) return 0
        return (px - py) * dir
      }      

      if (sort.key === "active") {
        const ax = Boolean(x.active)
        const ay = Boolean(y.active)
        if (ax === ay) return 0
        return (ax ? 1 : -1) * dir
      }

      if (sort.key === "category") {
        const cx = (x.category ?? "미분류").trim() || "미분류"
        const cy = (y.category ?? "미분류").trim() || "미분류"
        const cmp = cx.localeCompare(cy, "ko")
        if (cmp !== 0) return cmp * dir
        return x.name.localeCompare(y.name, "ko") * dir
      }

      return x.name.localeCompare(y.name, "ko") * dir
    })

    return arr
  }, [a.data.products, sort])

  const toggleSort = (key: "createdAt" | "name" | "category" | "active") => {
    setSort((prev) => {
      if (prev.key !== key) return { key, dir: "asc" }
      return { key, dir: prev.dir === "asc" ? "desc" : "asc" }
    })
  }

  const sortIndicator = (key: "createdAt" | "name" | "category" | "active") => {
    if (sort.key !== key) return null
    return <span className="text-muted-foreground">{sort.dir === "asc" ? "▲" : "▼"}</span>
  }

  const filteredProducts = useMemo(() => {
    if (productListCategory === "all") return sortedProducts
    if (productListCategory === "uncategorized") return sortedProducts.filter((p) => !p.category)
    return sortedProducts.filter((p) => (p.category ?? "") === productListCategory)
  }, [sortedProducts, productListCategory])

  const searchedProducts = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return filteredProducts
    return filteredProducts.filter((p) => (p.name ?? "").toLowerCase().includes(q))
  }, [filteredProducts, query])

  const totalPages = Math.max(1, Math.ceil(searchedProducts.length / ITEMS_PER_PAGE))
  const safePage = Math.min(productListPage, totalPages)
  const pagedProducts = useMemo(() => {
    const start = (safePage - 1) * ITEMS_PER_PAGE
    return searchedProducts.slice(start, start + ITEMS_PER_PAGE)
  }, [searchedProducts, safePage])

  if (safePage !== productListPage) setProductListPage(safePage)

  if (a.errorMsg) return <ErrorState message={a.errorMsg} onRetry={a.refresh} />

  return (
    <div className="space-y-6">
      {a.loading && <div className="text-sm text-muted-foreground">동기화 중…</div>}

      {/* 제품 추가 / CSV */}
      <div className="rounded-xl border bg-card/60 p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="min-w-0">
            <div className="text-sm font-semibold">제품 추가</div>
            <div className="text-xs text-muted-foreground">카테고리와 제품명을 입력하고 추가하세요.</div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <AppButton type="button" variant="outline" onClick={a.handleProductCsvUpload}>
              CSV 템플릿 다운로드
            </AppButton>

            <AppButton
              type="button"
              variant="outline"
              onClick={() => a.csvInputRef.current?.click()}
              disabled={a.loading || a.csvBusy}
            >
              CSV로 제품 일괄 추가/업데이트
            </AppButton>

            <input
              ref={a.csvInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              onChange={a.onChangeProductCsv}
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2 min-w-0">
          <Popover
            open={a.categoryOpen}
            onOpenChange={(open) => {
              a.setCategoryOpen(open)
              if (!open) a.setCategoryTyped(false)
            }}
          >
            <div className="flex-[1_1_180px] min-w-[160px] max-w-[240px]">
              <PopoverTrigger asChild>
                <AppButton type="button" variant="outline" className="w-full justify-between font-normal">
                  <span className="truncate">{a.newCategory.trim() ? a.newCategory : "카테고리 입력/선택"}</span>
                  <span className="text-muted-foreground">▾</span>
                </AppButton>
              </PopoverTrigger>

              <PopoverContent align="start" className="p-0 w-[--radix-popover-trigger-width]">
                <Command>
                  <CommandInput
                    placeholder="카테고리 검색/입력..."
                    value={a.newCategory}
                    onValueChange={(v) => {
                      a.setCategoryTyped(true)
                      a.setNewCategory(v)
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        a.saveCategoryOnly()
                      }
                    }}
                  />
                  <CommandList>
                    <CommandEmpty>
                      <div className="px-2 py-2 text-sm text-muted-foreground">
                        검색 결과가 없습니다.
                        {a.newCategory.trim() ? " Enter로 새 카테고리를 저장할 수 있어요." : ""}
                      </div>
                    </CommandEmpty>

                    <CommandGroup>
                      {a.categoryOptions
                        .filter((c) => {
                          const q = a.newCategory.trim()
                          if (!q) return true
                          return c.includes(q)
                        })
                        .map((c) => (
                          <CommandItem
                            key={c}
                            value={c}
                            onSelect={() => {
                              a.setCategoryTyped(false)
                              a.setNewCategory(c)
                              a.setCategoryOpen(false)
                            }}
                            className="flex items-center justify-between"
                          >
                            <span className="truncate">{c}</span>
                            <AppButton
                              type="button"
                              variant="ghost"
                              size="icon-sm"
                              className="text-destructive"
                              onClick={(e) => {
                                e.preventDefault()
                                e.stopPropagation()
                                setDeleteCategoryName(c)
                              }}
                              title="카테고리 삭제"
                            >
                              ×
                            </AppButton>
                          </CommandItem>
                        ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </div>
          </Popover>

          <AppInput
            id="product-name-input"
            className="flex-[2_1_220px] min-w-0"
            value={a.newProductName}
            onChange={(e) => a.setNewProductName(e.target.value)}
            placeholder="예: 미드나잇블루"
            onKeyDown={(e) => {
              if (e.key === "Enter") a.addProduct()
            }}
          />

          <AppButton className="flex-shrink-0 whitespace-nowrap" onClick={a.addProduct} disabled={a.loading}>
            추가
          </AppButton>
        </div>
      </div>

      {/* 제품 목록 */}
      <AppCard density="compact" title="제품 목록" className="min-w-0" contentClassName="space-y-3">
      <div className="grid gap-2 sm:grid-cols-[160px_140px_1fr_auto] items-center">
  {/* 카테고리 */}
  <AppSelect
    value={productListCategory}
    onValueChange={(v) => {
      setProductListCategory(v)
      setProductListPage(1)
    }}
    options={[
      { value: "all", label: "전체" },
      { value: "uncategorized", label: "미분류" },
      ...a.categoryOptions.map((c) => ({ value: c, label: c })),
    ]}
    className="w-full"
  />

  {/* 정렬 */}
  <AppSelect
    value={`${sort.key}:${sort.dir}`}
    onValueChange={(v) => {
      const [k, d] = v.split(":") as any
      setSort({ key: k, dir: d })
    }}
    options={[
      { value: "createdAt:desc", label: "최신순" },
      { value: "createdAt:asc", label: "오래된순" },
      { value: "name:asc", label: "제품명 A→Z" },
      { value: "name:desc", label: "제품명 Z→A" },
      { value: "category:asc", label: "카테고리 A→Z" },
      { value: "category:desc", label: "카테고리 Z→A" },
      { value: "price:asc", label: "가격 낮은순" },
      { value: "price:desc", label: "가격 높은순" },
    ]}
    className="w-full"
  />

  {/* 검색 */}
  <AppInput
    value={query}
    onChange={(e) => {
      setQuery(e.target.value)
      setProductListPage(1)
    }}
    placeholder="제품명 검색"
    className="w-full"
  />

  {/* 카운트 */}
  <div className="text-xs text-muted-foreground justify-self-end whitespace-nowrap">
    {searchedProducts.length}개 중 {pagedProducts.length}개 표시
  </div>
</div>

        {a.loading ? (
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : pagedProducts.length === 0 ? (
          <EmptyState
            title="표시할 제품이 없습니다"
            description={productListCategory === "all" ? "먼저 제품을 추가하거나 CSV로 업로드하세요." : "다른 카테고리를 선택하거나 제품을 추가하세요."}
          />
        ) : (
          <>
          <div className="overflow-x-auto rounded-xl border">
            <Table className="w-full table-fixed text-sm">
              <TableHeader>
                <TableRow>
                  <TableHead className={`${COL.category} text-center`}>카테고리</TableHead>
                  <TableHead className={`${COL.name} text-left`}>
                    <button type="button" onClick={() => toggleSort("name")} className="inline-flex items-center gap-1">
                      제품명 {sortIndicator("name")}
                    </button>
                  </TableHead>
                  <TableHead className={`${COL.price} px-1 text-right`}>가격</TableHead>
                  <TableHead className={`${COL.sku} text-center`}>SKU</TableHead>
                  <TableHead className={`${COL.barcode} text-center`}>바코드</TableHead>
                  <TableHead className={`${COL.status} text-center`}>상태</TableHead>
                  <TableHead className={`${COL.actions} text-right`}>작업</TableHead>
                </TableRow>
              </TableHeader>

              <TableBody>
                {pagedProducts.map((p) => {
                  const isEditing = a.editingProductId === p.id

                  return (
                    <TableRow key={p.id}>
                      <TableCell className={`${COL.category} align-top px-2 py-2 text-center`}>
                        {isEditing ? (
                          <AppSelect
                            value={a.editingProductCategory || ""}
                            onValueChange={(v) => a.setEditingProductCategory(v)}
                            options={[
                              { value: "", label: "미분류" },
                              ...a.categories.map((name) => ({ value: name, label: name })),
                            ]}
                          />
                        ) : (
                          <AppBadge variant="outline" className="max-w-[96px] truncate">
                            {p.category ? p.category : "미분류"}
                          </AppBadge>
                        )}
                      </TableCell>

                      <TableCell className={`${COL.name} align-top px-2 py-2`}>
                        {isEditing ? (
                          <AppInput
                            value={a.editingProductName}
                            onChange={(e) => a.setEditingProductName(e.target.value)}
                            placeholder="제품명"
                          />
                        ) : (
                          <div className="min-w-0 flex items-center gap-2">
                            <div className="truncate text-sm font-medium">{p.name}</div>
                            {p.makeEnabled === false ? (
                              <AppBadge variant="secondary" className="shrink-0">
                                제작중지
                              </AppBadge>
                            ) : null}
                          </div>
                        )}
                      </TableCell>

                      <TableCell className={`${COL.price} align-top px-1 py-2 text-right whitespace-nowrap`}>
                        {isEditing ? (
                          <AppInput
                            type="number"
                            inputMode="numeric"
                            value={String(editingPrice)}
                            onChange={(e) => {
                              const v = e.target.value
                              setEditingPrice(v === "" ? 0 : Math.max(0, parseInt(v, 10) || 0))
                            }}
                            placeholder="0"
                          />
                        ) : (
                          <span className="tabular-nums">{(p.price ?? 0).toLocaleString("ko-KR")}</span>
                        )}
                      </TableCell>

                      <TableCell className={`${COL.sku} align-top px-2 py-2 text-center`}>
                        {isEditing ? (
                          <AppInput value={editingSku} onChange={(e) => setEditingSku(e.target.value)} placeholder="-" />
                        ) : (
                          <span className="truncate block">{p.sku ? p.sku : "-"}</span>
                        )}
                      </TableCell>

                      <TableCell className={`${COL.barcode} align-top px-2 py-2 text-center`}>
                        {isEditing ? (
                          <AppInput value={editingBarcode} onChange={(e) => setEditingBarcode(e.target.value)} placeholder="-" />
                        ) : (
                          <span className="truncate block">{p.barcode ? p.barcode : "-"}</span>
                        )}
                      </TableCell>

                      <TableCell className={`${COL.status} align-top px-2 py-2`}>
                        <div className="flex items-center justify-center gap-3">
                          <div className="flex items-center gap-1">
                            <AppSwitch
                              checked={Boolean(p.active)}
                              onCheckedChange={(v) => {
                                const next = Boolean(v)
                                if (next !== Boolean(p.active)) a.toggleProductActiveFlip(p.id)
                              }}
                              disabled={a.loading}
                            />
                            <span className="text-[11px] text-muted-foreground select-none">판매</span>
                          </div>

                          <div className="flex items-center gap-1">
                            <AppSwitch
                              checked={p.makeEnabled !== false}
                              onCheckedChange={(v) => {
                                const next = Boolean(v)
                                const cur = p.makeEnabled !== false
                                if (next !== cur) a.toggleProductMakeEnabledFlip(p.id)
                              }}
                              disabled={a.loading}
                            />
                            <span className="text-[11px] text-muted-foreground select-none">제작</span>
                          </div>
                        </div>
                      </TableCell>

                      <TableCell className={`${COL.actions} align-top px-2 py-2 text-right`}>
                        {isEditing ? (
                          <div className="flex justify-end gap-2">
                            <AppButton
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => {
                                a.setEditingProductName(a.editingOriginalRef.current)
                                a.setEditingProductCategory(a.editingOriginalCategoryRef.current)
                                setEditingPrice(editPriceRef.current)
                                setEditingSku(editSkuRef.current)
                                setEditingBarcode(editBarcodeRef.current)
                                a.setEditingProductId(null)
                              }}
                            >
                              취소
                            </AppButton>

                            <AppButton
                              type="button"
                              size="sm"
                              onClick={async () => {
                                await a.saveProductFieldsExtended(p.id, {
                                  name: a.editingProductName,
                                  category: a.editingProductCategory,
                                  price: editingPrice,
                                  sku: editingSku,
                                  barcode: editingBarcode,
                                })
                                a.setEditingProductId(null)
                              }}
                            >
                              저장
                            </AppButton>
                          </div>
                        ) : (
                          <div className="flex justify-end">
                            <ProductRowActions
                              disabled={a.loading}
                              onEdit={() => {
                                a.setEditingProductId(p.id)
                                a.setEditingProductName(p.name)
                                a.editingOriginalRef.current = p.name

                                a.setEditingProductCategory(p.category ?? "")
                                a.editingOriginalCategoryRef.current = p.category ?? ""

                                const price0 = p.price ?? 0
                                const sku0 = p.sku ?? ""
                                const barcode0 = p.barcode ?? ""

                                editPriceRef.current = price0
                                editSkuRef.current = sku0
                                editBarcodeRef.current = barcode0

                                setEditingPrice(price0)
                                setEditingSku(sku0)
                                setEditingBarcode(barcode0)
                              }}
                              onDeleteRequest={() => {
                                setDeleteProductId(p.id)
                                setDeleteProductName(p.name)
                              }}
                            />
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </div>
          {totalPages > 1 && (
      <div className="flex flex-wrap justify-center gap-2 pt-3">
        {Array.from({ length: totalPages }).map((_, idx) => {
          const pageNum = idx + 1
          const active = pageNum === safePage
          return (
            <AppButton
              key={pageNum}
              type="button"
              size="sm"
              variant={active ? "default" : "outline"}
              onClick={() => setProductListPage(pageNum)}
            >
              {pageNum}
            </AppButton>
          )
        })}
      </div>
    )}
  </>
        )}
      </AppCard>

      <ConfirmDialog
        open={Boolean(deleteProductId)}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteProductId("")
            setDeleteProductName("")
          }
        }}
        title="제품을 삭제할까요?"
        description={deleteProductName ? `“${deleteProductName}” 제품이 삭제됩니다. 되돌릴 수 없습니다.` : "제품이 삭제됩니다. 되돌릴 수 없습니다."}
        confirmText="삭제"
        cancelText="취소"
        destructive
        busy={a.loading}
        onConfirm={async () => {
          const id = deleteProductId
          if (!id) return
          try {
            await a.deleteProduct(id)
          } catch {
            toast.error("삭제에 실패했어요.")
          } finally {
            setDeleteProductId("")
            setDeleteProductName("")
          }
        }}
      />

      <ConfirmDialog
        open={Boolean(deleteCategoryName)}
        onOpenChange={(open) => {
          if (!open) setDeleteCategoryName("")
        }}
        title="카테고리를 삭제할까요?"
        description={
          deleteCategoryName
            ? `“${deleteCategoryName}” 카테고리가 삭제됩니다. (제품의 카테고리 값은 유지됩니다)`
            : "카테고리가 삭제됩니다. (제품의 카테고리 값은 유지됩니다)"
        }
        confirmText="삭제"
        cancelText="취소"
        destructive
        busy={a.loading}
        onConfirm={async () => {
          const name = deleteCategoryName
          if (!name) return
          await a.deleteCategory(name)
          setDeleteCategoryName("")
        }}
      />
    </div>
  )
}
