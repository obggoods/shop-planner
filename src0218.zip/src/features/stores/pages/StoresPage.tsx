import PageHeader from "@/app/layout/PageHeader"
import StoresManager from "@/features/stores/components/StoresManager"
import { AppButton } from "@/components/app/AppButton"

export default function StoresPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="입점처"
        description="입점처 생성/삭제 및 입점처별 취급 제품 ON/OFF"
        action={
          <AppButton
            type="button"
            onClick={() => {
              const el = document.getElementById("store-name-input") as HTMLInputElement | null
              el?.focus()
            }}
          >
            입점처 추가
          </AppButton>
        }
      />

      <StoresManager />
    </div>
  )
}
