// src/features/dashboard/components/DashboardView.tsx
import { useMemo, useState } from "react"

import { useAppData } from "@/features/core/useAppData"
import { AppCard } from "@/components/app/AppCard"
import { AppBadge } from "@/components/app/AppBadge"
import { AppButton } from "@/components/app/AppButton"
import { AppSelect } from "@/components/app/AppSelect"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

import { EmptyState } from "@/components/shared/EmptyState"
import { Skeleton } from "@/components/shared/Skeleton"
import { ErrorState } from "@/components/shared/ErrorState"

function toInt(v: string, fallback: number) {
  const n = Number.parseInt((v ?? "").trim(), 10)
  return Number.isFinite(n) ? n : fallback
}

function KpiCard(props: {
  label: string
  value: string
  helper?: string
  badge?: React.ReactNode
  trend?: { value: number; label?: string }
}) {
  const trendColor =
    props.trend && props.trend.value > 0
      ? "text-emerald-600"
      : props.trend && props.trend.value < 0
      ? "text-red-600"
      : "text-muted-foreground"

  return (
    <AppCard
      density="compact"
      title={
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>{props.label}</span>
            {props.badge}
          </div>

          {props.trend && (
            <div className={`text-xs font-medium ${trendColor}`}>
              {props.trend.value > 0 ? "▲" : props.trend.value < 0 ? "▼" : ""}
              {Math.abs(props.trend.value)}%
              {props.trend.label ? ` ${props.trend.label}` : ""}
            </div>
          )}
        </div>
      }
      description={props.helper}
      className="h-full"
    >
      <div className="text-2xl font-semibold tracking-tight">{props.value}</div>
    </AppCard>
  )
}

export default function DashboardView() {
  const a = useAppData()

  // ✅ 훅은 전부 컴포넌트 내부
  const [tab, setTab] = useState<"overview" | "lowstock">("overview")
  const [storeFilter, setStoreFilter] = useState<string>("all")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")

  const lowStockThreshold = useMemo(
    () => toInt(a.lowStockThresholdInput, 2),
    [a.lowStockThresholdInput]
  )
  const targetQty = useMemo(
    () => toInt(a.defaultTargetQtyInput, 5),
    [a.defaultTargetQtyInput]
  )

  const storeById = useMemo(
    () => new Map(a.data.stores.map((s) => [s.id, s])),
    [a.data.stores]
  )
  const productById = useMemo(
    () => new Map(a.data.products.map((p) => [p.id, p])),
    [a.data.products]
  )

  // ✅ 카테고리 목록은 metrics 밖에서 분리
  const categories = useMemo(() => {
    const set = new Set<string>()
    a.data.products.forEach((p: any) => {
      // 프로젝트에 따라 필드명이 categoryName일 수도 있어서 안전 처리
      const c = (p.category ?? p.categoryName ?? "").toString().trim()
      if (c) set.add(c)
    })
    return Array.from(set).sort((x, y) => x.localeCompare(y))
  }, [a.data.products])

  // ✅ 입점처 목록도 분리 (AppSelect options 용)
const stores = useMemo(() => {
    return (a.data.stores ?? [])
      .map((s: any) => ({
        id: (s.id ?? "").toString(),
        name: (s.name ?? s.storeName ?? s.title ?? "").toString().trim(),
      }))
      .filter((s) => s.id && s.name)
      .sort((x, y) => x.name.localeCompare(y.name))
  }, [a.data.stores])  

  const enabledPairSet = useMemo(() => {
    const m = new Map<string, boolean>()
    for (const x of a.data.storeProductStates) {
      m.set(`${x.storeId}::${x.productId}`, x.enabled)
    }
    return m
  }, [a.data.storeProductStates])

  const invIndex = useMemo(() => {
    const m = new Map<string, number>()
    for (const it of a.data.inventory) {
      m.set(`${it.storeId}::${it.productId}`, it.onHandQty)
    }
    return m
  }, [a.data.inventory])

  const metrics = useMemo(() => {
    const productsTotal = a.data.products.length
    const productsActive = a.data.products.filter((p) => p.active).length
    const storesTotal = a.data.stores.length

    let enabledPairs = 0
    let lowStockPairs = 0

    const rows: Array<{
      storeId: string
      productId: string
      onHand: number
      need: number
    }> = []

    for (const s of a.data.stores) {
      for (const p of a.data.products) {
        if (!p.active) continue

        const enabled = enabledPairSet.get(`${s.id}::${p.id}`) ?? true
        if (!enabled) continue

        enabledPairs += 1
        const onHand = invIndex.get(`${s.id}::${p.id}`) ?? 0

        if (onHand < lowStockThreshold) {
          lowStockPairs += 1
          rows.push({
            storeId: s.id,
            productId: p.id,
            onHand,
            need: Math.max(0, targetQty - onHand),
          })
        }
      }
    }

    rows.sort((a, b) => {
      if (a.onHand !== b.onHand) return a.onHand - b.onHand
      return b.need - a.need
    })

    return {
      productsTotal,
      productsActive,
      storesTotal,
      enabledPairs,
      lowStockPairs,
      lowStockRows: rows,
    }
  }, [
    a.data.products,
    a.data.stores,
    enabledPairSet,
    invIndex,
    lowStockThreshold,
    targetQty,
  ])

  // ✅ 필터 적용된 rows
  const filteredRows = useMemo(() => {
    return metrics.lowStockRows.filter((r) => {
      const p: any = productById.get(r.productId)
      if (!p) return false

      if (storeFilter !== "all" && r.storeId !== storeFilter) return false

      const pc = (p.category ?? p.categoryName ?? "").toString().trim()
      if (categoryFilter !== "all" && pc !== categoryFilter) return false

      return true
    })
  }, [metrics.lowStockRows, storeFilter, categoryFilter, productById])

  if (a.errorMsg) return <ErrorState message={a.errorMsg} onRetry={a.refresh} />
  if (a.loading) return <Skeleton />
  if (a.data.stores.length === 0 || a.data.products.length === 0) {
    return (
      <EmptyState
        title="대시보드 데이터를 만들기 시작해요"
        description="입점처와 제품을 먼저 추가하면 KPI와 재고 경고가 표시됩니다."
      />
    )
  }

  return (
    <div className="space-y-6">
      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="overview">요약</TabsTrigger>
          <TabsTrigger value="lowstock">
            재고 경고
            {metrics.lowStockPairs > 0 ? (
              <AppBadge className="ml-1" variant="destructive">
                {metrics.lowStockPairs}
              </AppBadge>
            ) : null}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
            <KpiCard label="총 제품" value={`${metrics.productsTotal}`} />
            <KpiCard
              label="활성 제품"
              value={`${metrics.productsActive}`}
              helper="현재 판매/관리 대상"
              trend={{ value: 12, label: "전월 대비" }} // ✅ 자리만 확보(나중에 실제 계산 연결)
            />
            <KpiCard label="입점처" value={`${metrics.storesTotal}`} />
            <KpiCard
              label="저재고 SKU"
              value={`${metrics.lowStockPairs}`}
              helper={`기준: ${lowStockThreshold} 미만`}
              badge={
                metrics.lowStockPairs > 0 ? (
                  <AppBadge variant="destructive">주의</AppBadge>
                ) : (
                  <AppBadge variant="secondary">정상</AppBadge>
                )
              }
            />
          </div>

          <AppCard
            title="저재고 상위 10"
            description={`목표 재고 ${targetQty} 기준으로 보충 필요 수량을 계산합니다.`}
            action={
              <AppButton variant="secondary" onClick={() => setTab("lowstock")}>
                전체 보기
              </AppButton>
            }
          >
            {metrics.lowStockRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                저재고 항목이 없습니다.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>입점처</TableHead>
                    <TableHead>제품</TableHead>
                    <TableHead className="text-right">보유</TableHead>
                    <TableHead className="text-right">필요</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {metrics.lowStockRows.slice(0, 10).map((r) => {
                    const s = storeById.get(r.storeId)
                    const p: any = productById.get(r.productId)
                    return (
                      <TableRow key={`${r.storeId}::${r.productId}`}>
                        <TableCell className="font-medium">
                          {s?.name ?? "-"}
                        </TableCell>
                        <TableCell>{p?.name ?? "-"}</TableCell>
                        <TableCell className="text-right">{r.onHand}</TableCell>
                        <TableCell className="text-right">{r.need}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </AppCard>
        </TabsContent>

        <TabsContent value="lowstock" className="space-y-6">
          {/* ✅ 필터 UI는 lowstock 탭 상단 */}
          <div className="flex flex-wrap gap-3">
          <AppSelect
  value={storeFilter}
  onValueChange={setStoreFilter}
  placeholder="전체 입점처"
  options={[
    { label: "전체", value: "all" },
    ...stores.map((s: { id: string; name: string }) => ({
      label: s.name,
      value: s.id,
    })),
  ]}
/>

<AppSelect
  value={categoryFilter}
  onValueChange={setCategoryFilter}
  placeholder="전체 카테고리"
  options={[
    { label: "전체", value: "all" },
    ...categories.map((c: string) => ({
      label: c,
      value: c,
    })),
  ]}
/>

          </div>

          <AppCard
            title="재고 경고 목록"
            description={`저재고 기준: ${lowStockThreshold} 미만 / 목표 재고: ${targetQty}`}
          >
            {filteredRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">
                조건에 맞는 항목이 없습니다.
              </div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>입점처</TableHead>
                    <TableHead>제품</TableHead>
                    <TableHead className="text-right">보유</TableHead>
                    <TableHead className="text-right">필요</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredRows.map((r) => {
                    const s = storeById.get(r.storeId)
                    const p: any = productById.get(r.productId)
                    return (
                      <TableRow key={`${r.storeId}::${r.productId}`}>
                        <TableCell className="font-medium">
                          {s?.name ?? "-"}
                        </TableCell>
                        <TableCell>{p?.name ?? "-"}</TableCell>
                        <TableCell className="text-right">{r.onHand}</TableCell>
                        <TableCell className="text-right">{r.need}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </AppCard>
        </TabsContent>
      </Tabs>
    </div>
  )
}
