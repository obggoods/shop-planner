import { useEffect, useMemo, useState } from "react"
import PageHeader from "@/app/layout/PageHeader"
import { AppSection } from "@/components/app/AppSection"
import { AppCard } from "@/components/app/AppCard"
import { AppButton } from "@/components/app/AppButton"
import { AppInput } from "@/components/app/AppInput"

import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

import { Plus, Trash2, Edit2, Copy, Library, ArrowDownToLine } from "lucide-react"

type Material = {
  id: string
  name: string
  unitPrice: number
  quantity: number
}

type LibraryItem = {
  id: string
  name: string
  unitPrice: number
  updatedAt: number
}

type Product = {
  id: string
  name: string
  memo?: string
  materials: Material[]

  // 인건비
  hourlyRate: number // 시급
  productionPerHour: number // 시간당 생산량(개) (perHour 모드)
  laborInputMode: "perHour" | "perItem"
  minutesPerItem?: number // perItem 모드(개당 분)

  // 기타
  outsourcingCost: number // 외주/가공비(개당)
  lossRate: number // 로스율(%)

  // 판매/수수료
  sellingPrice: number // 판매가
  salesCommissionRate: number // 판매수수료(%)
  vatRate: number // VAT(%)

  createdAt: number
}

const PRODUCTS_STORAGE_KEY = "stocknmake-margin-products-v1"
const MATERIAL_LIBRARY_KEY = "stocknmake-material-library-v1"

function generateId() {
  return Math.random().toString(36).slice(2, 9)
}

function clamp(n: number, min: number, max?: number) {
  const v = Number.isFinite(n) ? n : min
  const a = Math.max(min, v)
  return max === undefined ? a : Math.min(max, a)
}

function toNumber(input: string) {
  const cleaned = String(input ?? "").replaceAll(",", "").trim()
  const n = Number(cleaned)
  return Number.isFinite(n) ? n : 0
}

function formatCurrency(n: number) {
  return `${Math.round(n).toLocaleString("ko-KR")}원`
}

function formatPercent(n: number) {
  return `${n.toFixed(1)}%`
}

function migrateProduct(p: any): Product {
  return {
    id: p?.id ?? generateId(),
    name: String(p?.name ?? ""),
    memo: String(p?.memo ?? ""),

    materials: Array.isArray(p?.materials)
      ? p.materials.map((m: any) => ({
          id: m?.id ?? generateId(),
          name: String(m?.name ?? ""),
          unitPrice: clamp(Number(m?.unitPrice ?? m?.cost ?? 0), 0),
          quantity: clamp(Number(m?.quantity ?? 1), 0.0001),
        }))
      : [],

    hourlyRate: clamp(Number(p?.hourlyRate ?? 0), 0),
    productionPerHour: clamp(Number(p?.productionPerHour ?? 1), 0.0001),
    laborInputMode: p?.laborInputMode === "perItem" ? "perItem" : "perHour",
    minutesPerItem: clamp(Number(p?.minutesPerItem ?? 0), 0),

    outsourcingCost: clamp(Number(p?.outsourcingCost ?? 0), 0),
    lossRate: clamp(Number(p?.lossRate ?? 0), 0, 100),

    sellingPrice: clamp(Number(p?.sellingPrice ?? 0), 0),
    salesCommissionRate: clamp(Number(p?.salesCommissionRate ?? 0), 0, 100),
    vatRate: clamp(Number(p?.vatRate ?? 10), 0, 100),

    createdAt: Number(p?.createdAt ?? Date.now()),
  }
}

function migrateLibraryItem(x: any): LibraryItem {
  return {
    id: x?.id ?? generateId(),
    name: String(x?.name ?? ""),
    unitPrice: clamp(Number(x?.unitPrice ?? x?.cost ?? 0), 0),
    updatedAt: Number(x?.updatedAt ?? Date.now()),
  }
}

function calcMaterialCost(materials: Material[]) {
  return materials.reduce((sum, m) => sum + (m.unitPrice || 0) * (m.quantity || 0), 0)
}

function calcLaborCost(p: Product) {
  if (p.laborInputMode === "perItem") {
    const minutes = clamp(Number(p.minutesPerItem ?? 0), 0)
    const hoursPerItem = minutes / 60
    return p.hourlyRate * hoursPerItem
  }
  const perHour = clamp(p.productionPerHour, 0.0001)
  return p.hourlyRate / perHour
}

function calcCOGS(p: Product) {
  const materials = calcMaterialCost(p.materials)
  const labor = calcLaborCost(p)
  const base = materials + labor + p.outsourcingCost
  const lossMultiplier = 1 + clamp(p.lossRate, 0, 100) / 100
  return base * lossMultiplier
}

function calcCommission(p: Product) {
  return p.sellingPrice * (clamp(p.salesCommissionRate, 0, 100) / 100)
}

function calcVat(p: Product) {
  // 단순 표시용: 판매가 기준 VAT 비용
  return p.sellingPrice * (clamp(p.vatRate, 0, 100) / 100)
}

function calcProfit(p: Product) {
  const cogs = calcCOGS(p)
  const commission = calcCommission(p)
  const vat = calcVat(p)
  return p.sellingPrice - cogs - commission - vat
}

function calcMarginRate(p: Product) {
  if (p.sellingPrice <= 0) return 0
  return (calcProfit(p) / p.sellingPrice) * 100
}

function emptyProduct(): Product {
  return {
    id: generateId(),
    name: "",
    memo: "",
    materials: [],
    hourlyRate: 0,
    productionPerHour: 1,
    laborInputMode: "perHour",
    minutesPerItem: 0,
    outsourcingCost: 0,
    lossRate: 0,
    sellingPrice: 0,
    salesCommissionRate: 0,
    vatRate: 10,
    createdAt: Date.now(),
  }
}

type MarginAssessment = {
  level: "danger" | "warn" | "good"
  label: string
  message: string
}

// 기본 프리셋(필요하면 나중에 설정 화면으로 뺄 수 있음)
function assessMargin(marginRate: number): MarginAssessment {
  if (marginRate < 0) {
    return { level: "danger", label: "적자", message: "원가/수수료/VAT가 판매가를 초과합니다. 판매가 인상 또는 원가 절감이 필요합니다." }
  }
  if (marginRate < 10) {
    return { level: "danger", label: "위험", message: "마진이 매우 낮습니다. 반품/할인/변동비를 고려하면 손익이 쉽게 무너집니다." }
  }
  if (marginRate < 20) {
    return { level: "warn", label: "보통", message: "기본은 되지만 이벤트/광고/CS 비용을 포함하면 타이트할 수 있습니다." }
  }
  if (marginRate < 35) {
    return { level: "good", label: "양호", message: "운영비/할인 여력까지 고려해 비교적 안정적인 구간입니다." }
  }
  return { level: "good", label: "매우 좋음", message: "충분한 여력이 있습니다. 다만 가격경쟁력/수요탄력도도 함께 확인하세요." }
}

function badgeClasses(level: MarginAssessment["level"]) {
  // shadcn class 기반(색은 tailwind 기본 토큰 사용)
  if (level === "danger") return "bg-destructive/10 text-destructive border-destructive/20"
  if (level === "warn") return "bg-amber-500/10 text-amber-700 border-amber-500/20 dark:text-amber-300"
  return "bg-emerald-500/10 text-emerald-700 border-emerald-500/20 dark:text-emerald-300"
}

export default function MarginCalculatorPage() {
  const [products, setProducts] = useState<Product[]>([])
  const [library, setLibrary] = useState<LibraryItem[]>([])

  const [dialogOpen, setDialogOpen] = useState(false)
  const [editing, setEditing] = useState<Product | null>(null)

  // 폼 상태(편집/추가)
  const [draft, setDraft] = useState<Product>(() => emptyProduct())

  // 재료 추가 입력
  const [newMaterialName, setNewMaterialName] = useState("")
  const [newMaterialUnitPrice, setNewMaterialUnitPrice] = useState("")
  const [newMaterialQty, setNewMaterialQty] = useState("1")

  // 라이브러리 UI
  const [libSearch, setLibSearch] = useState("")
  const [libUnitPriceEdit, setLibUnitPriceEdit] = useState<Record<string, string>>({})

  useEffect(() => {
    // products load
    const raw = localStorage.getItem(PRODUCTS_STORAGE_KEY)
    if (raw) {
      try {
        const parsed = JSON.parse(raw)
        if (Array.isArray(parsed)) setProducts(parsed.map(migrateProduct))
      } catch (e) {
        console.error("[MarginCalculator] failed to load products", e)
      }
    }

    // library load
    const rawLib = localStorage.getItem(MATERIAL_LIBRARY_KEY)
    if (rawLib) {
      try {
        const parsed = JSON.parse(rawLib)
        if (Array.isArray(parsed)) {
          const items = parsed.map(migrateLibraryItem)
          setLibrary(items)
          // 편집용 입력 초기화
          const init: Record<string, string> = {}
          items.forEach((it) => (init[it.id] = String(it.unitPrice)))
          setLibUnitPriceEdit(init)
        }
      } catch (e) {
        console.error("[MarginCalculator] failed to load library", e)
      }
    }
  }, [])

  useEffect(() => {
    localStorage.setItem(PRODUCTS_STORAGE_KEY, JSON.stringify(products))
  }, [products])

  useEffect(() => {
    localStorage.setItem(MATERIAL_LIBRARY_KEY, JSON.stringify(library))
  }, [library])

  const sortedProducts = useMemo(() => {
    return [...products].sort((a, b) => (b.createdAt ?? 0) - (a.createdAt ?? 0))
  }, [products])

  const sortedLibrary = useMemo(() => {
    const q = libSearch.trim().toLowerCase()
    const filtered = q
      ? library.filter((x) => x.name.toLowerCase().includes(q))
      : library
    return [...filtered].sort((a, b) => (b.updatedAt ?? 0) - (a.updatedAt ?? 0))
  }, [library, libSearch])

  const openCreate = () => {
    setEditing(null)
    setDraft(emptyProduct())
    setNewMaterialName("")
    setNewMaterialUnitPrice("")
    setNewMaterialQty("1")
    setDialogOpen(true)
  }

  const openEdit = (p: Product) => {
    setEditing(p)
    setDraft(migrateProduct(p))
    setNewMaterialName("")
    setNewMaterialUnitPrice("")
    setNewMaterialQty("1")
    setDialogOpen(true)
  }

  const saveDraft = () => {
    const normalized = migrateProduct({
      ...draft,
      createdAt: editing ? editing.createdAt : Date.now(),
    })
    if (!normalized.name.trim()) return

    setProducts((prev) => {
      if (!editing) return [normalized, ...prev]
      return prev.map((x) => (x.id === editing.id ? normalized : x))
    })
    setDialogOpen(false)
  }

  const deleteProduct = (id: string) => {
    setProducts((prev) => prev.filter((p) => p.id !== id))
  }

  const duplicateProduct = (p: Product) => {
    const copy: Product = {
      ...migrateProduct(p),
      id: generateId(),
      name: `${p.name} (복사본)`,
      createdAt: Date.now(),
    }
    setProducts((prev) => [copy, ...prev])
  }

  const addMaterialToDraft = (name?: string, unitPrice?: number) => {
    const n = (name ?? newMaterialName).trim()
    if (!n) return

    const up = clamp(unitPrice ?? toNumber(newMaterialUnitPrice), 0)
    const qty = clamp(toNumber(newMaterialQty), 0.0001)

    const m: Material = { id: generateId(), name: n, unitPrice: up, quantity: qty }
    setDraft((prev) => ({ ...prev, materials: [...prev.materials, m] }))

    // manual 입력일 때만 초기화
    if (!name) {
      setNewMaterialName("")
      setNewMaterialUnitPrice("")
      setNewMaterialQty("1")
    }
  }

  const updateMaterial = (id: string, patch: Partial<Material>) => {
    setDraft((prev) => ({
      ...prev,
      materials: prev.materials.map((m) => (m.id === id ? { ...m, ...patch } : m)),
    }))
  }

  const removeMaterial = (id: string) => {
    setDraft((prev) => ({ ...prev, materials: prev.materials.filter((m) => m.id !== id) }))
  }

  // 라이브러리: 추가/갱신
  const upsertLibraryItem = (name: string, unitPrice: number) => {
    const n = name.trim()
    if (!n) return

    setLibrary((prev) => {
      const existing = prev.find((x) => x.name.trim().toLowerCase() === n.toLowerCase())
      if (existing) {
        const next = prev.map((x) =>
          x.id === existing.id ? { ...x, unitPrice: clamp(unitPrice, 0), updatedAt: Date.now() } : x
        )
        // edit input sync
        setLibUnitPriceEdit((m) => ({ ...m, [existing.id]: String(clamp(unitPrice, 0)) }))
        return next
      }
      const created: LibraryItem = { id: generateId(), name: n, unitPrice: clamp(unitPrice, 0), updatedAt: Date.now() }
      setLibUnitPriceEdit((m) => ({ ...m, [created.id]: String(created.unitPrice) }))
      return [created, ...prev]
    })
  }

  const deleteLibraryItem = (id: string) => {
    setLibrary((prev) => prev.filter((x) => x.id !== id))
    setLibUnitPriceEdit((m) => {
      const copy = { ...m }
      delete copy[id]
      return copy
    })
  }

  const addDraftMaterialToLibrary = (m: Material) => {
    upsertLibraryItem(m.name, m.unitPrice)
  }

  const addFromLibraryToDraft = (it: LibraryItem) => {
    addMaterialToDraft(it.name, it.unitPrice)
  }

  const saveLibraryUnitPrice = (it: LibraryItem) => {
    const raw = libUnitPriceEdit[it.id] ?? String(it.unitPrice)
    const v = clamp(toNumber(raw), 0)
    upsertLibraryItem(it.name, v)
  }

  const draftSummary = useMemo(() => {
    const cogs = calcCOGS(draft)
    const commission = calcCommission(draft)
    const vat = calcVat(draft)
    const profit = calcProfit(draft)
    const margin = calcMarginRate(draft)
    const assessment = assessMargin(margin)
    return { cogs, commission, vat, profit, margin, assessment }
  }, [draft])

  return (
    <AppSection>
      <PageHeader
        title="마진 계산기"
        description="제품별 원가·수수료·VAT를 기준으로 마진을 계산하고 저장합니다."
        action={
          <AppButton onClick={openCreate}>
            <Plus className="mr-2 h-4 w-4" />
            제품 추가
          </AppButton>
        }
      />

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* 좌측: 제품 목록 */}
        <AppCard
          title="저장된 제품"
          description={sortedProducts.length ? `총 ${sortedProducts.length}개` : "아직 저장된 제품이 없습니다."}
        >
          {sortedProducts.length === 0 ? (
            <div className="text-sm text-muted-foreground">오른쪽 상단 “제품 추가”로 시작하세요.</div>
          ) : (
            <div className="space-y-4">
              {sortedProducts.map((p) => {
                const cogs = calcCOGS(p)
                const profit = calcProfit(p)
                const margin = calcMarginRate(p)
                const assessment = assessMargin(margin)

                return (
                  <div key={p.id} className="rounded-lg border p-4 space-y-3">
                    <div className="flex items-start justify-between gap-3">
                      <div className="min-w-0">
                        <div className="flex items-center gap-2">
                          <div className="font-medium truncate">{p.name}</div>
                          <span className={`text-xs px-2 py-0.5 rounded border ${badgeClasses(assessment.level)}`}>
                            {assessment.label}
                          </span>
                        </div>
                        {p.memo ? (
                          <div className="text-xs text-muted-foreground mt-1 line-clamp-2">{p.memo}</div>
                        ) : null}
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <AppButton variant="secondary" size="sm" onClick={() => duplicateProduct(p)}>
                          <Copy className="h-4 w-4" />
                        </AppButton>
                        <AppButton variant="secondary" size="sm" onClick={() => openEdit(p)}>
                          <Edit2 className="h-4 w-4" />
                        </AppButton>
                        <AppButton variant="destructive" size="sm" onClick={() => deleteProduct(p.id)}>
                          <Trash2 className="h-4 w-4" />
                        </AppButton>
                      </div>
                    </div>

                    <Separator />

                    <div className="grid grid-cols-2 gap-3 text-sm">
                      <div>
                        <div className="text-muted-foreground">판매가</div>
                        <div className="font-medium">{formatCurrency(p.sellingPrice)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">총원가(COGS)</div>
                        <div className="font-medium">{formatCurrency(cogs)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">이익</div>
                        <div className="font-medium">{formatCurrency(profit)}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">마진율</div>
                        <div className="font-medium">{formatPercent(margin)}</div>
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground">{assessment.message}</div>
                  </div>
                )
              })}
            </div>
          )}
        </AppCard>

        {/* 우측: 추가/편집 다이얼로그 + 라이브러리 */}
        <AppCard
          title="계산/저장"
          description="제품을 추가하거나 편집합니다. (저장은 로컬 브라우저에 저장됩니다)"
          action={
            <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
              <DialogTrigger asChild>
                <AppButton variant="secondary" onClick={openCreate}>
                  <Plus className="mr-2 h-4 w-4" />
                  새로 만들기
                </AppButton>
              </DialogTrigger>

              <DialogContent className="max-w-4xl">
                <DialogHeader>
                  <DialogTitle>{editing ? "제품 편집" : "제품 추가"}</DialogTitle>
                </DialogHeader>

                <Tabs defaultValue="product" className="w-full">
                  <TabsList className="grid w-full grid-cols-2">
                    <TabsTrigger value="product">제품 입력</TabsTrigger>
                    <TabsTrigger value="library">
                      <Library className="mr-2 h-4 w-4" />
                      원부자재 라이브러리
                    </TabsTrigger>
                  </TabsList>

                  {/* 제품 입력 탭 */}
                  <TabsContent value="product" className="space-y-6 pt-4">
                    {/* 기본 정보 */}
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <Label>제품명</Label>
                        <AppInput
                          value={draft.name}
                          onChange={(e) => setDraft((p) => ({ ...p, name: e.target.value }))}
                          placeholder="예: 카드지갑"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>메모(선택)</Label>
                        <AppInput
                          value={draft.memo ?? ""}
                          onChange={(e) => setDraft((p) => ({ ...p, memo: e.target.value }))}
                          placeholder="예: 원단 A + 부자재 B"
                        />
                      </div>
                    </div>

                    {/* 재료 */}
                    <div className="space-y-3">
                      <div className="font-medium text-sm">재료/부자재</div>

                      <div className="grid grid-cols-1 gap-3 md:grid-cols-4">
                        <div className="space-y-2 md:col-span-2">
                          <Label>이름</Label>
                          <AppInput
                            value={newMaterialName}
                            onChange={(e) => setNewMaterialName(e.target.value)}
                            placeholder="예: 원단"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>단가</Label>
                          <AppInput
                            inputMode="numeric"
                            value={newMaterialUnitPrice}
                            onChange={(e) => setNewMaterialUnitPrice(e.target.value)}
                            placeholder="예: 2500"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>수량</Label>
                          <AppInput
                            inputMode="decimal"
                            value={newMaterialQty}
                            onChange={(e) => setNewMaterialQty(e.target.value)}
                            placeholder="예: 0.5"
                          />
                        </div>
                      </div>

                      <div className="flex justify-end">
                        <AppButton variant="secondary" onClick={() => addMaterialToDraft()}>
                          <Plus className="mr-2 h-4 w-4" />
                          재료 추가
                        </AppButton>
                      </div>

                      {draft.materials.length ? (
                        <div className="rounded-lg border overflow-hidden">
                          <Table>
                            <TableHeader>
                              <TableRow>
                                <TableHead>이름</TableHead>
                                <TableHead className="w-36">단가</TableHead>
                                <TableHead className="w-28">수량</TableHead>
                                <TableHead className="w-24 text-right">합계</TableHead>
                                <TableHead className="w-28 text-right">라이브러리</TableHead>
                                <TableHead className="w-16"></TableHead>
                              </TableRow>
                            </TableHeader>
                            <TableBody>
                              {draft.materials.map((m) => {
                                const total = (m.unitPrice || 0) * (m.quantity || 0)
                                return (
                                  <TableRow key={m.id}>
                                    <TableCell>
                                      <AppInput
                                        value={m.name}
                                        onChange={(e) => updateMaterial(m.id, { name: e.target.value })}
                                      />
                                    </TableCell>
                                    <TableCell>
                                      <AppInput
                                        inputMode="numeric"
                                        value={String(m.unitPrice)}
                                        onChange={(e) =>
                                          updateMaterial(m.id, { unitPrice: clamp(toNumber(e.target.value), 0) })
                                        }
                                      />
                                    </TableCell>
                                    <TableCell>
                                      <AppInput
                                        inputMode="decimal"
                                        value={String(m.quantity)}
                                        onChange={(e) =>
                                          updateMaterial(m.id, { quantity: clamp(toNumber(e.target.value), 0.0001) })
                                        }
                                      />
                                    </TableCell>
                                    <TableCell className="text-right text-sm">{formatCurrency(total)}</TableCell>
                                    <TableCell className="text-right">
                                      <AppButton
                                        variant="secondary"
                                        size="sm"
                                        onClick={() => addDraftMaterialToLibrary(m)}
                                        title="이 재료를 라이브러리에 저장/갱신"
                                      >
                                        <ArrowDownToLine className="h-4 w-4" />
                                      </AppButton>
                                    </TableCell>
                                    <TableCell className="text-right">
                                      <AppButton variant="destructive" size="sm" onClick={() => removeMaterial(m.id)}>
                                        <Trash2 className="h-4 w-4" />
                                      </AppButton>
                                    </TableCell>
                                  </TableRow>
                                )
                              })}
                            </TableBody>
                          </Table>
                        </div>
                      ) : (
                        <div className="text-sm text-muted-foreground">재료를 추가하세요.</div>
                      )}
                    </div>

                    <Separator />

                    {/* 인건비 */}
                    <div className="space-y-3">
                      <div className="font-medium text-sm">인건비</div>

                      <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                        <div className="space-y-2">
                          <Label>시급</Label>
                          <AppInput
                            inputMode="numeric"
                            value={String(draft.hourlyRate)}
                            onChange={(e) =>
                              setDraft((p) => ({ ...p, hourlyRate: clamp(toNumber(e.target.value), 0) }))
                            }
                            placeholder="예: 12000"
                          />
                        </div>

                        <div className="space-y-2">
                          <Label>입력 방식</Label>
                          <div className="flex gap-2">
                            <AppButton
                              variant={draft.laborInputMode === "perHour" ? "default" : "secondary"}
                              size="sm"
                              onClick={() => setDraft((p) => ({ ...p, laborInputMode: "perHour" }))}
                            >
                              시간당 생산량
                            </AppButton>
                            <AppButton
                              variant={draft.laborInputMode === "perItem" ? "default" : "secondary"}
                              size="sm"
                              onClick={() => setDraft((p) => ({ ...p, laborInputMode: "perItem" }))}
                            >
                              개당 소요시간
                            </AppButton>
                          </div>
                        </div>

                        {draft.laborInputMode === "perHour" ? (
                          <div className="space-y-2">
                            <Label>시간당 생산량(개)</Label>
                            <AppInput
                              inputMode="decimal"
                              value={String(draft.productionPerHour)}
                              onChange={(e) =>
                                setDraft((p) => ({
                                  ...p,
                                  productionPerHour: clamp(toNumber(e.target.value), 0.0001),
                                }))
                              }
                              placeholder="예: 2"
                            />
                          </div>
                        ) : (
                          <div className="space-y-2">
                            <Label>개당 소요시간(분)</Label>
                            <AppInput
                              inputMode="decimal"
                              value={String(draft.minutesPerItem ?? 0)}
                              onChange={(e) =>
                                setDraft((p) => ({
                                  ...p,
                                  minutesPerItem: clamp(toNumber(e.target.value), 0),
                                }))
                              }
                              placeholder="예: 15"
                            />
                          </div>
                        )}
                      </div>
                    </div>

                    <Separator />

                    {/* 기타/판매 */}
                    <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                      <div className="space-y-2">
                        <Label>외주/가공비(개당)</Label>
                        <AppInput
                          inputMode="numeric"
                          value={String(draft.outsourcingCost)}
                          onChange={(e) =>
                            setDraft((p) => ({ ...p, outsourcingCost: clamp(toNumber(e.target.value), 0) }))
                          }
                          placeholder="예: 0"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>로스율(%)</Label>
                        <AppInput
                          inputMode="decimal"
                          value={String(draft.lossRate)}
                          onChange={(e) =>
                            setDraft((p) => ({ ...p, lossRate: clamp(toNumber(e.target.value), 0, 100) }))
                          }
                          placeholder="예: 5"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>판매가</Label>
                        <AppInput
                          inputMode="numeric"
                          value={String(draft.sellingPrice)}
                          onChange={(e) =>
                            setDraft((p) => ({ ...p, sellingPrice: clamp(toNumber(e.target.value), 0) }))
                          }
                          placeholder="예: 30000"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>판매수수료율(%)</Label>
                        <AppInput
                          inputMode="decimal"
                          value={String(draft.salesCommissionRate)}
                          onChange={(e) =>
                            setDraft((p) => ({ ...p, salesCommissionRate: clamp(toNumber(e.target.value), 0, 100) }))
                          }
                          placeholder="예: 10"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>VAT(%)</Label>
                        <AppInput
                          inputMode="decimal"
                          value={String(draft.vatRate)}
                          onChange={(e) => setDraft((p) => ({ ...p, vatRate: clamp(toNumber(e.target.value), 0, 100) }))}
                          placeholder="예: 10"
                        />
                      </div>
                    </div>

                    {/* 미리보기 + 평가 */}
                    <div className="rounded-lg bg-muted/40 p-4 space-y-3 text-sm">
                      <div className="flex items-center justify-between gap-3">
                        <div className="font-medium">미리보기</div>
                        <span className={`text-xs px-2 py-0.5 rounded border ${badgeClasses(draftSummary.assessment.level)}`}>
                          {draftSummary.assessment.label}
                        </span>
                      </div>

                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <div className="text-muted-foreground">총원가(COGS)</div>
                          <div className="font-medium">{formatCurrency(draftSummary.cogs)}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">수수료</div>
                          <div className="font-medium">{formatCurrency(draftSummary.commission)}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">VAT</div>
                          <div className="font-medium">{formatCurrency(draftSummary.vat)}</div>
                        </div>
                        <div>
                          <div className="text-muted-foreground">이익 / 마진율</div>
                          <div className="font-medium">
                            {formatCurrency(draftSummary.profit)} · {formatPercent(draftSummary.margin)}
                          </div>
                        </div>
                      </div>

                      <div className="text-xs text-muted-foreground">{draftSummary.assessment.message}</div>
                    </div>

                    <div className="flex justify-end gap-2">
                      <AppButton variant="secondary" onClick={() => setDialogOpen(false)}>
                        취소
                      </AppButton>
                      <AppButton onClick={saveDraft} disabled={!draft.name.trim()}>
                        저장
                      </AppButton>
                    </div>
                  </TabsContent>

                  {/* 라이브러리 탭 */}
                  <TabsContent value="library" className="space-y-4 pt-4">
                    <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                      <div className="md:col-span-2 space-y-2">
                        <Label>검색</Label>
                        <AppInput
                          value={libSearch}
                          onChange={(e) => setLibSearch(e.target.value)}
                          placeholder="예: 원단, 지퍼, 라벨..."
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>빠른 추가 (이름)</Label>
                        <AppInput
                          value={newMaterialName}
                          onChange={(e) => setNewMaterialName(e.target.value)}
                          placeholder="예: 지퍼"
                        />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 gap-3 md:grid-cols-3">
                      <div className="space-y-2">
                        <Label>빠른 추가 (단가)</Label>
                        <AppInput
                          inputMode="numeric"
                          value={newMaterialUnitPrice}
                          onChange={(e) => setNewMaterialUnitPrice(e.target.value)}
                          placeholder="예: 300"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label>빠른 추가 (수량)</Label>
                        <AppInput
                          inputMode="decimal"
                          value={newMaterialQty}
                          onChange={(e) => setNewMaterialQty(e.target.value)}
                          placeholder="예: 1"
                        />
                      </div>
                      <div className="flex items-end justify-end gap-2">
                        <AppButton
                          variant="secondary"
                          onClick={() => {
                            const name = newMaterialName.trim()
                            const price = clamp(toNumber(newMaterialUnitPrice), 0)
                            if (!name) return
                            upsertLibraryItem(name, price)
                          }}
                          title="이름 기준으로 라이브러리에 저장/갱신"
                        >
                          <ArrowDownToLine className="mr-2 h-4 w-4" />
                          라이브러리 저장
                        </AppButton>

                        <AppButton
                          onClick={() => {
                            const name = newMaterialName.trim()
                            const price = clamp(toNumber(newMaterialUnitPrice), 0)
                            if (!name) return
                            addMaterialToDraft(name, price)
                          }}
                          title="현재 수량으로 제품 재료에 추가"
                        >
                          <Plus className="mr-2 h-4 w-4" />
                          제품에 추가
                        </AppButton>
                      </div>
                    </div>

                    <Separator />

                    {sortedLibrary.length === 0 ? (
                      <div className="text-sm text-muted-foreground">
                        아직 라이브러리가 비어 있습니다. 제품 재료에서 “라이브러리 저장” 버튼을 눌러 쌓아두세요.
                      </div>
                    ) : (
                      <div className="rounded-lg border overflow-hidden">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>이름</TableHead>
                              <TableHead className="w-44">단가</TableHead>
                              <TableHead className="w-24 text-right">추가</TableHead>
                              <TableHead className="w-16"></TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {sortedLibrary.map((it) => (
                              <TableRow key={it.id}>
                                <TableCell className="font-medium">{it.name}</TableCell>
                                <TableCell>
                                  <div className="flex gap-2">
                                    <AppInput
                                      inputMode="numeric"
                                      value={libUnitPriceEdit[it.id] ?? String(it.unitPrice)}
                                      onChange={(e) =>
                                        setLibUnitPriceEdit((m) => ({ ...m, [it.id]: e.target.value }))
                                      }
                                    />
                                    <AppButton variant="secondary" size="sm" onClick={() => saveLibraryUnitPrice(it)}>
                                      저장
                                    </AppButton>
                                  </div>
                                </TableCell>
                                <TableCell className="text-right">
                                  <AppButton
                                    variant="secondary"
                                    size="sm"
                                    onClick={() => addFromLibraryToDraft(it)}
                                    title="현재 수량으로 제품 재료에 추가"
                                  >
                                    <Plus className="h-4 w-4" />
                                  </AppButton>
                                </TableCell>
                                <TableCell className="text-right">
                                  <AppButton variant="destructive" size="sm" onClick={() => deleteLibraryItem(it.id)}>
                                    <Trash2 className="h-4 w-4" />
                                  </AppButton>
                                </TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}

                    <div className="rounded-lg border p-4 text-sm space-y-2">
                      <div className="font-medium">사용 방법</div>
                      <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                        <li>제품 입력 탭의 재료 테이블에서 “라이브러리 저장” 버튼으로 자주 쓰는 재료 단가를 저장합니다.</li>
                        <li>라이브러리 탭에서 원하는 재료를 “+”로 제품 재료에 추가할 수 있습니다(수량은 상단 수량 입력값 사용).</li>
                        <li>동일 이름 재료는 “저장” 시 자동으로 단가가 갱신됩니다.</li>
                      </ul>
                    </div>
                  </TabsContent>
                </Tabs>
              </DialogContent>
            </Dialog>
          }
        >
          <div className="space-y-4 text-sm">
            <div className="text-muted-foreground">
              “제품 추가”로 계산하고 저장하세요. 저장 데이터는 현재 브라우저(localStorage)에만 저장됩니다.
            </div>

            <div className="rounded-lg border p-4 space-y-2">
              <div className="font-medium">계산 기준</div>
              <ul className="list-disc pl-5 space-y-1 text-muted-foreground">
                <li>총원가(COGS) = (재료 + 인건비 + 외주/가공비) × (1 + 로스율)</li>
                <li>이익 = 판매가 - 총원가 - 수수료 - VAT</li>
                <li>마진율 = 이익 ÷ 판매가</li>
                <li>마진 평가는 기본 프리셋(0/10/20/35%) 기준이며, 필요하면 나중에 사용자 설정으로 뺄 수 있습니다.</li>
              </ul>
            </div>
          </div>
        </AppCard>
      </div>
    </AppSection>
  )
}
