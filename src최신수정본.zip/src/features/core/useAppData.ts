// src/features/core/useAppData.ts
// Shared state + actions previously in Master.tsx, extracted for feature pages.

import { useCallback, useEffect, useMemo, useRef, useState } from "react"
import type { ChangeEvent } from "react"
import { toast } from "@/lib/toast"

import type { AppData } from "@/data/models"
import { downloadJson, generateId, readJsonFile } from "@/data/store"
import {
  loadDataFromDB,
  ensureStoreProductStatesSeedDB,
  setStoreProductEnabledDB,
  setStoreProductsEnabledBulkDB,
  createProductDB,
  createStoreDB,
  deleteProductDB,
  deleteStoreDB,
  loadCategoriesDB,
  upsertCategoryDB,
  deleteCategoryDB,
} from "@/data/store.supabase"
import {
  getOrCreateMyProfile,
  updateMyDefaultTargetQty,
  updateMyLowStockThreshold,
} from "@/lib/supabaseClient"

/** ✅ CSV row 타입(템플릿: category,name,active) */
type ProductCsvRow = { category: string; name: string; active: boolean }

function normalizeCategoryKey(raw: string | null | undefined) {
  return (raw ?? "").trim()
}

function normalizeNameKey(raw: string | null | undefined) {
  return (raw ?? "").trim()
}

const EMPTY: AppData = {
  schemaVersion: 1,
  products: [],
  stores: [],
  inventory: [],
  storeProductStates: [],
  settlements: [],
  plans: [],
  updatedAt: Date.now(),
}

function parseBooleanLike(v: string): boolean {
  const t = (v ?? "").trim().toLowerCase()
  if (t === "") return true
  if (["true", "t", "1", "y", "yes", "on", "활성"].includes(t)) return true
  if (["false", "f", "0", "n", "no", "off", "비활성"].includes(t)) return false
  return true
}

// 단순 CSV 파서(템플릿 기준). 복잡한 인용부호 케이스는 지원하지 않음.
function parseSimpleCSV(text: string): ProductCsvRow[] {
  const lines = text
    .replace(/\r\n/g, "\n")
    .replace(/\r/g, "\n")
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l.length > 0)

  if (lines.length === 0) return []

  const header = lines[0].split(",").map((x) => x.trim().toLowerCase())
  const idxCategory = header.indexOf("category")
  const idxName = header.indexOf("name")
  const idxActive = header.indexOf("active")

  if (idxName === -1 || idxActive === -1) {
    throw new Error('CSV 헤더에 "name,active"가 필요합니다. (권장: category,name,active)')
  }

  const rows: ProductCsvRow[] = []

  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split(",").map((x) => x.trim())
    const category = idxCategory >= 0 ? cols[idxCategory] ?? "" : ""
    const name = cols[idxName] ?? ""
    const activeRaw = cols[idxActive] ?? ""

    rows.push({ category, name, active: parseBooleanLike(activeRaw) })
  }

  return rows
}

function downloadCsv(filename: string, csvBody: string) {
  const blob = new Blob(["\uFEFF" + csvBody], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

export function useAppData() {
  const [data, setData] = useState<AppData>(EMPTY)
  const [loading, setLoading] = useState(true)
  const [errorMsg, setErrorMsg] = useState<string | null>(null)

  // ✅ refresh 중복 호출 방지
  const refreshInFlightRef = useRef<Promise<void> | null>(null)
  const refreshQueuedRef = useRef(false)

  // ✅ 유저별 설정
  const [defaultTargetQtyInput, setDefaultTargetQtyInput] = useState<string>("5")
  const [lowStockThresholdInput, setLowStockThresholdInput] = useState<string>("2")
  const [profileLoading, setProfileLoading] = useState(true)
  const [profileSaving, setProfileSaving] = useState(false)

  // ✅ CSV 업로드
  const csvInputRef = useRef<HTMLInputElement | null>(null)
  const [csvBusy, setCsvBusy] = useState(false)

  const [newProductName, setNewProductName] = useState("")
  const [newStoreName, setNewStoreName] = useState("")

  // ✅ 제품명/카테고리 수정 UI 상태
  const [editingProductId, setEditingProductId] = useState<string | null>(null)
  const [editingProductName, setEditingProductName] = useState<string>("")
  const editingOriginalRef = useRef<string>("")
  const [editingProductCategory, setEditingProductCategory] = useState<string>("")
  const editingOriginalCategoryRef = useRef<string>("")

  // ✅ 카테고리 콤보박스
  const [newCategory, setNewCategory] = useState<string>("")
  const [categoryTyped, setCategoryTyped] = useState(false)
  const [categoryOpen, setCategoryOpen] = useState(false)
  const [categories, setCategories] = useState<string[]>([])

  const categoryOptions = useMemo(() => {
    const set = new Set<string>()
    for (const c of categories) {
      const v = String(c).trim()
      if (v) set.add(v)
    }
    return Array.from(set).sort((a, b) => a.localeCompare(b, "ko"))
  }, [categories])

  const normalizedCategory = useMemo(() => newCategory.trim(), [newCategory])
  const isExistingCategory = useMemo(
    () => normalizedCategory !== "" && categoryOptions.includes(normalizedCategory),
    [normalizedCategory, categoryOptions]
  )

  // ===== profile bootstrap =====
  useEffect(() => {
    let alive = true

    ;(async () => {
      try {
        setProfileLoading(true)
        const profile = await getOrCreateMyProfile()
        if (!alive) return
        setDefaultTargetQtyInput(String(profile.default_target_qty))
        setLowStockThresholdInput(String(profile.low_stock_threshold ?? 2))
      } catch (e) {
        console.error("[profiles] failed to load profile", e)
      } finally {
        if (alive) setProfileLoading(false)
      }
    })()

    return () => {
      alive = false
    }
  }, [])

  const refresh = useCallback(async () => {
    if (refreshInFlightRef.current) {
      refreshQueuedRef.current = true
      return refreshInFlightRef.current
    }

    const p = (async () => {
      setLoading(true)
      setErrorMsg(null)
      try {
        const next = await loadDataFromDB()
        setData(next)
        await ensureStoreProductStatesSeedDB({
          storeIds: next.stores.map((s) => s.id),
          productIds: next.products.map((p) => p.id),
        })
        const cats = await loadCategoriesDB()
        setCategories(cats)
      } catch (e: any) {
        console.error(e)
        setErrorMsg(e?.message ?? "데이터 로드 실패")
      } finally {
        setLoading(false)
      }
    })()

    refreshInFlightRef.current = p
    await p
    refreshInFlightRef.current = null

    if (refreshQueuedRef.current) {
      refreshQueuedRef.current = false
      await refresh()
    }
  }, [])

  useEffect(() => {
    refresh()
  }, [refresh])

  // ===== category =====
  const saveCategoryOnly = useCallback(async () => {
    const c = newCategory.trim()
    if (!c) return
    if (categoryOptions.includes(c)) {
      setCategoryOpen(false)
      return
    }

    try {
      await upsertCategoryDB(c)
      toast.success("카테고리를 저장했어요.")
      setNewCategory("")
      setCategoryTyped(false)
      setCategoryOpen(false)
      await refresh()
    } catch {
      toast.error("카테고리 저장에 실패했어요.")
    }
  }, [newCategory, categoryOptions, refresh])

  const deleteCategory = useCallback(
    async (c: string) => {
      const name = (c ?? "").trim()
      if (!name) return
      try {
        await deleteCategoryDB(name)
        toast.success("카테고리를 삭제했어요.")
        await refresh()
      } catch {
        toast.error("카테고리 삭제에 실패했어요.")
      }
    },
    [refresh]
  )

  // ===== products =====
  const addProduct = useCallback(async () => {
    const name = newProductName.trim()
    const categoryToSave = newCategory.trim() === "" ? null : newCategory.trim()
    if (!name) return

    const p = {
      id: generateId("p"),
      name,
      category: categoryToSave,
      active: true,
      makeEnabled: true,
      createdAt: Date.now(),
    }

    const prevProducts = data.products
    const prevCategories = categories

    setData((prev) => ({
      ...prev,
      products: [p, ...prev.products],
      updatedAt: Date.now(),
    }))

    if (categoryToSave) {
      setCategories((prev) => {
        const set = new Set(prev.map((x) => x.trim()))
        set.add(categoryToSave.trim())
        return Array.from(set)
      })
    }

    setNewProductName("")
    setNewCategory("")
    setCategoryTyped(false)

    try {
      if (categoryToSave) await upsertCategoryDB(categoryToSave)
      await createProductDB(p as any)
      toast.success("제품을 추가했어요.")
    } catch (e: any) {
      console.error(e)
      setData((prev) => ({ ...prev, products: prevProducts, updatedAt: Date.now() }))
      setCategories(prevCategories)
      toast.error(`제품 추가 실패: ${e?.message ?? e}`)
      await refresh()
    }
  }, [newProductName, newCategory, data.products, categories, refresh])

  const deleteProduct = useCallback(
    async (productId: string) => {
      await deleteProductDB(productId)
      await refresh()
      toast.success("제품을 삭제했어요.")
    },
    [refresh]
  )

  // 제품 활성/비활성 (Optimistic + upsert)
  const toggleProductActiveFlip = useCallback(
    async (productId: string) => {
      const hit = data.products.find((p) => p.id === productId)
      if (!hit) return

      const next = { ...hit, active: !hit.active }
      const prevProducts = data.products

      setData((prev) => ({
        ...prev,
        products: prev.products.map((p) => (p.id === productId ? next : p)),
        updatedAt: Date.now(),
      }))

      try {
        await createProductDB(next)
      } catch (e) {
        console.error(e)
        setData((prev) => ({ ...prev, products: prevProducts, updatedAt: Date.now() }))
        toast.error("상태 변경 실패 (로그인 / 권한 / RLS 확인)")
      }
    },
    [data.products]
  )

  // 제품 제작대상 ON/OFF (Optimistic + upsert)
  const toggleProductMakeEnabledFlip = useCallback(
    async (productId: string) => {
      const hit = data.products.find((p) => p.id === productId)
      if (!hit) return

      const next = { ...hit, makeEnabled: !(hit.makeEnabled ?? true) }
      const prevProducts = data.products

      setData((prev) => ({
        ...prev,
        products: prev.products.map((p) => (p.id === productId ? next : p)),
        updatedAt: Date.now(),
      }))

      try {
        await createProductDB(next)
      } catch (e) {
        console.error(e)
        setData((prev) => ({ ...prev, products: prevProducts, updatedAt: Date.now() }))
        toast.error("제작대상 변경 실패 (로그인 / 권한 / RLS 확인)")
      }
    },
    [data.products]
  )

  // 제품명/카테고리 저장 (Optimistic + upsert)
  const saveProductFieldsSimple = useCallback(
    async (productId: string, nextNameRaw: string, nextCategoryRaw: string) => {
      const hit = data.products.find((p) => p.id === productId)
      if (!hit) return

      const nextName = nextNameRaw.trim()
      const nextCategory = nextCategoryRaw.trim()

      if (!nextName) {
        toast.error("제품명은 비워둘 수 없어요.")
        return
      }

      const normalizedCategory = nextCategory === "" || nextCategory === "미분류" ? "" : nextCategory
      if (nextName === hit.name && (normalizedCategory || "") === (hit.category || "")) return

      const prevProducts = data.products
      const next = { ...hit, name: nextName, category: normalizedCategory || null }

      setData((prev) => ({
        ...prev,
        products: prev.products.map((p) => (p.id === productId ? next : p)),
        updatedAt: Date.now(),
      }))

      try {
        if (next.category && !categoryOptions.includes(next.category)) {
          await upsertCategoryDB(next.category)
        }
        await createProductDB(next)
        await refresh()
        toast.success("제품 정보를 저장했어요.")
      } catch (e: any) {
        console.error(e)
        setData((prev) => ({ ...prev, products: prevProducts, updatedAt: Date.now() }))
        toast.error(`저장 실패: ${e?.message ?? e}`)
        await refresh()
      }
    },
    [data.products, categoryOptions, refresh]
  )

  // ===== stores =====
  const addStore = useCallback(async () => {
    const name = newStoreName.trim()
    if (!name) return
    const s = {
      id: generateId("s"),
      name,
      createdAt: Date.now(),
    }

    const prevStores = data.stores

    setData((prev) => ({
      ...prev,
      stores: [s, ...prev.stores],
      updatedAt: Date.now(),
    }))
    setNewStoreName("")

    try {
      await createStoreDB(s as any)
      toast.success("입점처를 추가했어요.")
    } catch (e: any) {
      console.error(e)
      setData((prev) => ({ ...prev, stores: prevStores, updatedAt: Date.now() }))
      toast.error(`입점처 추가 실패: ${e?.message ?? e}`)
      await refresh()
    }
  }, [newStoreName, data.stores, refresh])

  const deleteStore = useCallback(
    async (storeId: string) => {
      await deleteStoreDB(storeId)
      await refresh()
      toast.success("입점처를 삭제했어요.")
    },
    [refresh]
  )

  const toggleOne = useCallback(
    async (storeId: string, productId: string, next: boolean) => {
      await setStoreProductEnabledDB({ storeId, productId, enabled: next })
      await refresh()
    },
    [refresh]
  )

  const toggleAll = useCallback(
    async (storeId: string, next: boolean) => {
      await setStoreProductsEnabledBulkDB({
        storeId,
        productIds: data.products.map((p) => p.id),
        enabled: next,
      })
      await refresh()
    },
    [data.products, refresh]
  )

  // ===== CSV products upload =====
  const handleProductCsvFile = useCallback(
    async (file: File) => {
      const text = await file.text()
      const rows = parseSimpleCSV(text)

      const cleaned: ProductCsvRow[] = rows
        .map((r) => ({
          category: (r.category ?? "").trim(),
          name: (r.name ?? "").trim(),
          active: parseBooleanLike(String((r as any).active ?? "")),
        }))
        .filter((r) => r.name.length > 0)

      if (cleaned.length === 0) {
        toast.error("업로드할 제품이 없습니다. (name이 비어있으면 무시됩니다)")
        return
      }

      // 중복 row(동일 category+name)는 마지막 값으로 덮어쓰기
      const byKey = new Map<string, ProductCsvRow>()
      for (const r of cleaned) {
        const key = `${normalizeCategoryKey(r.category)}||${normalizeNameKey(r.name)}`
        byKey.set(key, r)
      }
      const uniqueRows: ProductCsvRow[] = Array.from(byKey.values())

      setCsvBusy(true)

      const prevData = data
      const prevCategories = categories

      try {
        const existing = new Map<string, any>()
        for (const p of data.products) {
          const key = `${normalizeCategoryKey(p.category)}||${normalizeNameKey(p.name)}`
          existing.set(key, p)
        }

        const nextProducts = [...data.products]
        const changed: any[] = []
        const newCats: string[] = []

        for (const r of uniqueRows) {
          const catTrim = r.category.trim()
          const categoryOrNull = catTrim === "" ? null : catTrim
          const key = `${normalizeCategoryKey(categoryOrNull ?? "")}||${normalizeNameKey(r.name)}`

          const hit = existing.get(key)

          if (hit) {
            const next = { ...hit, active: r.active }
            const idx = nextProducts.findIndex((x) => x.id === hit.id)
            if (idx >= 0) nextProducts[idx] = next
            changed.push(next)
          } else {
            const p = {
              id: generateId("p"),
              name: r.name,
              category: categoryOrNull,
              active: r.active,
              makeEnabled: true,
              createdAt: Date.now(),
            }
            nextProducts.unshift(p)
            existing.set(key, p)
            changed.push(p)
            if (categoryOrNull) newCats.push(categoryOrNull)
          }
        }

        // 1) UI 반영
        setData((prev) => ({ ...prev, products: nextProducts, updatedAt: Date.now() }))

        if (newCats.length > 0) {
          const set = new Set([...categories.map((x) => x.trim()), ...newCats.map((x) => x.trim())].filter(Boolean))
          setCategories(Array.from(set))
        }

        // 2) DB 반영
        const catSet = new Set(newCats.map((x) => x.trim()).filter(Boolean))
        for (const c of catSet) {
          await upsertCategoryDB(c)
        }
        for (const p of changed) {
          await createProductDB(p)
        }

        toast.success(`CSV 반영 완료: ${changed.length}건 처리됨`)
        await refresh()
      } catch (e: any) {
        console.error(e)
        setData(prevData)
        setCategories(prevCategories)
        toast.error(`CSV 업로드 실패: ${e?.message ?? e}`)
        await refresh()
      } finally {
        setCsvBusy(false)
        if (csvInputRef.current) csvInputRef.current.value = ""
      }
    },
    [data, categories, refresh]
  )

  const onChangeProductCsv = useCallback(
    async (e: ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (!file) return

      await handleProductCsvFile(file)
    },
    [handleProductCsvFile]
  )

  const handleProductCsvUpload = useCallback(() => {
    const template = "category,name,active\n상의,반팔티,true\n하의,청바지,true\n,카테고리없음,true\n"
    downloadCsv("products_template.csv", template)
    toast.success("CSV 템플릿을 다운로드했어요.")
  }, [])

  // ===== backup/restore (local only) =====
  const fileInputRef = useRef<HTMLInputElement | null>(null)

  const handleBackup = useCallback(async () => {
    try {
      downloadJson("stocknmake-backup.json", data)
      toast.success("백업(JSON) 다운로드 완료")
    } catch (e) {
      console.error(e)
      toast.error("백업 실패")
    }
  }, [data])

  const handleRestore = useCallback(async (file: File) => {
    try {
      const parsed = (await readJsonFile(file)) as Partial<AppData>
      if (!parsed || parsed.schemaVersion !== 1) {
        toast.error("백업 파일 형식이 올바르지 않습니다 (schemaVersion 불일치)")
        return
      }
      const next: AppData = {
        schemaVersion: 1,
        products: parsed.products ?? [],
        stores: parsed.stores ?? [],
        inventory: parsed.inventory ?? [],
        storeProductStates: parsed.storeProductStates ?? [],
        settlements: parsed.settlements ?? [],
        plans: parsed.plans ?? [],
        updatedAt: Date.now(),
      }
      setData(next)
      toast.success("복구(로컬 반영) 완료")
    } catch {
      toast.error("복구 실패: JSON 파일을 읽을 수 없습니다")
    } finally {
      if (fileInputRef.current) fileInputRef.current.value = ""
    }
  }, [])

  const saveDefaultTargetQty = useCallback(async () => {
    const val =
      defaultTargetQtyInput.trim() === ""
        ? 0
        : Math.max(0, parseInt(defaultTargetQtyInput, 10) || 0)
    setDefaultTargetQtyInput(String(val))
    try {
      setProfileSaving(true)
      await updateMyDefaultTargetQty(val)
      toast.success("재고 기준을 저장했어요.")
    } catch {
      toast.error("저장에 실패했어요.")
    } finally {
      setProfileSaving(false)
    }
  }, [defaultTargetQtyInput])

  const saveLowStockThreshold = useCallback(async () => {
    const val =
      lowStockThresholdInput.trim() === ""
        ? 0
        : Math.max(0, parseInt(lowStockThresholdInput, 10) || 0)
    setLowStockThresholdInput(String(val))
    try {
      setProfileSaving(true)
      await updateMyLowStockThreshold(val)
      toast.success("재고 기준을 저장했어요.")
    } catch {
      toast.error("저장에 실패했어요.")
    } finally {
      setProfileSaving(false)
    }
  }, [lowStockThresholdInput])

  return {
    data,
    setData,
    loading,
    errorMsg,
    refresh,

    // profile
    profileLoading,
    profileSaving,
    defaultTargetQtyInput,
    setDefaultTargetQtyInput,
    lowStockThresholdInput,
    setLowStockThresholdInput,
    saveDefaultTargetQty,
    saveLowStockThreshold,

    // categories
    categories,
    categoryOptions,
    newCategory,
    setNewCategory,
    categoryTyped,
    setCategoryTyped,
    categoryOpen,
    setCategoryOpen,
    isExistingCategory,
    saveCategoryOnly,
    deleteCategory,

    // products
    newProductName,
    setNewProductName,
    addProduct,
    deleteProduct,
    toggleProductActiveFlip,
    toggleProductMakeEnabledFlip,
    saveProductFieldsSimple,
    editingProductId,
    setEditingProductId,
    editingProductName,
    setEditingProductName,
    editingOriginalRef,
    editingProductCategory,
    setEditingProductCategory,
    editingOriginalCategoryRef,

    // stores
    newStoreName,
    setNewStoreName,
    addStore,
    deleteStore,
    toggleOne,
    toggleAll,

    // csv
    csvInputRef,
    csvBusy,
    handleProductCsvUpload,
    onChangeProductCsv,

    // backup/restore
    fileInputRef,
    handleBackup,
    handleRestore,
  }
}
