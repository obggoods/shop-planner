import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export type AppSelectOption = { value: string; label: string }

export function AppSelect(props: {
  value: string
  onValueChange: (v: string) => void
  options: AppSelectOption[]
  placeholder?: string
  disabled?: boolean
  className?: string
}) {
  const { value, onValueChange, options, placeholder = "선택", disabled, className } = props

  return (
    <Select value={value || undefined} onValueChange={onValueChange} disabled={disabled}>
      <SelectTrigger className={className}>
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value || "__empty"} value={o.value}>
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
