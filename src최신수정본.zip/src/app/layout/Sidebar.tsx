import { NavLink } from "react-router-dom"

const navItems = [
  { to: "/dashboard", label: "대시보드" },
  { to: "/products", label: "제품" },
  { to: "/stores", label: "입점처" },
  { to: "/margin", label: "마진 계산기" },
  { to: "/settings", label: "설정" },
] as const

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ")
}

export default function Sidebar(props: { isAdmin: boolean }) {
  const { isAdmin } = props

  const items = [
    ...navItems,
    ...(isAdmin ? [{ to: "/admin/invites", label: "관리자" } as const] : []),
  ]

  return (
    <aside className="hidden md:flex md:w-60 md:flex-col md:border-r md:bg-background">
      <div className="h-14 px-4 flex items-center border-b">
        <NavLink to="/dashboard" className="font-semibold text-sm">
          스톡앤메이크
        </NavLink>
      </div>

      <nav className="flex-1 p-2 space-y-1">
        {items.map((it) => (
          <NavLink
            key={it.to}
            to={it.to}
            className={({ isActive }) =>
              cx(
                "block rounded-lg px-3 py-2 text-sm transition-colors",
                "hover:bg-accent hover:text-accent-foreground",
                isActive && "bg-accent text-accent-foreground"
              )
            }
          >
            {it.label}
          </NavLink>
        ))}
      </nav>
    </aside>
  )
}
