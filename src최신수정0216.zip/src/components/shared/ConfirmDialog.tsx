import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { AppButton } from "@/components/app/AppButton"

export function ConfirmDialog(props: {
  open: boolean
  onOpenChange: (open: boolean) => void
  title: string
  description?: string
  confirmText?: string
  cancelText?: string
  destructive?: boolean
  busy?: boolean
  onConfirm: () => void | Promise<void>
}) {
  const {
    open,
    onOpenChange,
    title,
    description,
    confirmText = "확인",
    cancelText = "취소",
    destructive = false,
    busy = false,
    onConfirm,
  } = props

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
        </DialogHeader>

        {description ? <p className="text-sm text-muted-foreground">{description}</p> : null}

        <DialogFooter className="gap-2 sm:gap-2">
          <AppButton type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={busy}>
            {cancelText}
          </AppButton>
          <AppButton
            type="button"
            variant={destructive ? "destructive" : "default"}
            onClick={onConfirm}
            disabled={busy}
          >
            {confirmText}
          </AppButton>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
