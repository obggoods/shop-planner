// src/App.tsx
import { Suspense, lazy, useEffect, useMemo, useState } from "react"
import { Routes, Route, Navigate, useLocation, useNavigate } from "react-router-dom"
import type { Session } from "@supabase/supabase-js"

import "./App.css"

import Login from "./pages/Login"
import Terms from "./pages/Terms"
import Privacy from "./pages/Privacy"
import Pricing from "./pages/Pricing"
import InviteGate from "./pages/InviteGate"
import ResetPassword from "./pages/ResetPassword"

import AppLayout from "./app/layout/AppLayout"

const DashboardPage = lazy(() => import("./features/dashboard/pages/DashboardPage"))
const ProductsPage = lazy(() => import("./features/products/pages/ProductsPage"))
const StoresPage = lazy(() => import("./features/stores/pages/StoresPage"))
const SettingsPage = lazy(() => import("./features/settings/pages/SettingsPage"))
const AdminInvites = lazy(() => import("./pages/AdminInvites"))
const MarginCalculatorPage = lazy(() => import("./features/margin/pages/MarginCalculatorPage"))

import { supabase, getOrCreateMyProfile } from "./lib/supabaseClient"

type MyProfile = {
  is_invited?: boolean
}

export default function App() {
  const nav = useNavigate()
  const location = useLocation()

  const [session, setSession] = useState<Session | null>(null)
  const [bootLoading, setBootLoading] = useState(true)

  const [profile, setProfile] = useState<MyProfile | null>(null)
  const [profileLoading, setProfileLoading] = useState(false)

  const [isAdmin, setIsAdmin] = useState(false)
  const [adminChecked, setAdminChecked] = useState(false)

  // ✅ 공개 페이지(약관/개인정보/가격)
  const isPublicLegalPage = useMemo(() => {
    const p = location.pathname
    return p === "/terms" || p === "/privacy" || p === "/pricing"
  }, [location.pathname])

  // ✅ 인증 페이지(헤더/탭 없이)
  const isAuthPage = useMemo(() => {
    const p = location.pathname
    return p === "/login" || p === "/reset-password"
  }, [location.pathname])

  // ✅ 0) 세션 부트스트랩 + Auth 상태 변화 구독
  useEffect(() => {
    let alive = true

    supabase.auth.getSession().then(({ data }) => {
      if (!alive) return
      setSession(data.session)
      setBootLoading(false)
    })

    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      setSession(newSession)
      setProfile(null)
      setIsAdmin(false)
      setAdminChecked(false)
    })

    return () => {
      alive = false
      sub.subscription.unsubscribe()
    }
  }, [])

  // ✅ 1) 로그인 상태에서만 프로필 로드 (초대 여부)
  useEffect(() => {
    let alive = true

    ;(async () => {
      if (!session) return

      try {
        setProfileLoading(true)
        const p = await getOrCreateMyProfile()
        if (!alive) return
        setProfile(p as MyProfile)
      } catch (e) {
        console.error("[App] profile load failed", e)
        if (!alive) return
        setProfile({ is_invited: false })
      } finally {
        if (alive) setProfileLoading(false)
      }
    })()

    return () => {
      alive = false
    }
  }, [session])

  // ✅ 2) 로그인 상태에서만 관리자 여부 체크
  useEffect(() => {
    let cancelled = false

    ;(async () => {
      if (!session) {
        if (!cancelled) {
          setIsAdmin(false)
          setAdminChecked(true)
        }
        return
      }

      const { data, error } = await supabase.rpc("is_admin")
      if (cancelled) return

      setIsAdmin(!error && !!data)
      setAdminChecked(true)
    })()

    return () => {
      cancelled = true
    }
  }, [session])

  if (bootLoading) return <div className="app-loading">로딩 중...</div>

  // ✅ 1) 공개 페이지는 무조건 통과 (Paddle 심사용)
  if (isPublicLegalPage) {
    return (
      <Routes>
        <Route path="/terms" element={<Terms />} />
        <Route path="/privacy" element={<Privacy />} />
        <Route path="/pricing" element={<Pricing />} />
        <Route path="*" element={<Navigate to="/terms" replace />} />
      </Routes>
    )
  }

  // ✅ 2) Auth 페이지(/login, /reset-password)는 헤더/탭 없이
  if (isAuthPage) {
    return (
      <Routes>
        <Route path="/login" element={session ? <Navigate to="/dashboard" replace /> : <Login />} />
        <Route path="/reset-password" element={<ResetPassword />} />
        <Route path="*" element={<Navigate to={session ? "/dashboard" : "/login"} replace />} />
      </Routes>
    )
  }

  // ✅ 3) 로그인 안 했으면 로그인으로
  if (!session) {
    return (
      <Routes>
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
    )
  }

  // ✅ 4) 로그인 했으면 프로필/관리자 확인이 끝날 때까지 대기
  if (profileLoading || !profile || !adminChecked) {
    return <div className="app-loading">초대 여부 확인 중…</div>
  }

  // ✅ 5) 관리자면 초대 없이 통과, 일반 유저는 초대 필요
  if (!isAdmin && profile.is_invited !== true) {
    return <InviteGate />
  }

  // ✅ 6) 초대(또는 관리자) 통과 → 앱 화면
  return (
    <Suspense fallback={<div className="app-loading">로딩 중...</div>}>
      <Routes>
        <Route
          element={
            <AppLayout
              sessionEmail={session.user.email ?? ""}
              isAdmin={isAdmin}
              onLogout={async () => {
                await supabase.auth.signOut()
                nav("/login")
              }}
            />
          }
        >
          <Route path="/" element={<Navigate to="/dashboard" replace />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/products" element={<ProductsPage />} />
          <Route path="/stores" element={<StoresPage />} />
          <Route path="/settings" element={<SettingsPage />} />
          <Route path="/margin" element={<MarginCalculatorPage />} />

          {/* Backward compat */}
          <Route path="/master" element={<Navigate to="/products" replace />} />

          <Route
            path="/admin/invites"
            element={isAdmin ? <AdminInvites /> : <Navigate to="/dashboard" replace />}
          />

          <Route path="*" element={<Navigate to="/dashboard" replace />} />
        </Route>
      </Routes>
    </Suspense>
  )
}
