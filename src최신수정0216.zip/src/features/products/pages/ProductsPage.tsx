import PageHeader from "@/app/layout/PageHeader"
import ProductsManager from "@/features/products/components/ProductsManager"
import { AppButton } from "@/components/app/AppButton"

export default function ProductsPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="제품"
        description="제품 생성/수정/삭제, 카테고리, 제작대상, CSV 업로드"
        action={
          <AppButton
            type="button"
            onClick={() => {
              const el = document.getElementById("product-name-input") as HTMLInputElement | null
              el?.focus()
            }}
          >
            제품 추가
          </AppButton>
        }
      />

      <ProductsManager />
    </div>
  )
}
