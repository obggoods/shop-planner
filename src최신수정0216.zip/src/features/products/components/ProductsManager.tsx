// src/features/products/components/ProductsManager.tsx
import { useMemo, useState } from "react"

import { AppButton } from "@/components/app/AppButton"
import { AppCard } from "@/components/app/AppCard"
import { AppInput } from "@/components/app/AppInput"
import { AppSwitch } from "@/components/app/AppSwitch"
import { AppSelect } from "@/components/app/AppSelect"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

import { useAppData } from "@/features/core/useAppData"
import { ConfirmDialog } from "@/components/shared/ConfirmDialog"
import { toast } from "@/lib/toast"
import { EmptyState } from "@/components/shared/EmptyState"
import { Skeleton } from "@/components/shared/Skeleton"
import { ErrorState } from "@/components/shared/ErrorState"
import { AppBadge } from "@/components/app/AppBadge"

const ITEMS_PER_PAGE = 20

export default function ProductsManager() {
  const a = useAppData()

  const [productListCategory, setProductListCategory] = useState<string>("all")
  const [productListPage, setProductListPage] = useState<number>(1)
  const [query, setQuery] = useState<string>("")
  const [sort, setSort] = useState<{ key: "createdAt" | "name" | "category" | "active"; dir: "asc" | "desc" }>({ key: "createdAt", dir: "desc" })

  const [deleteProductId, setDeleteProductId] = useState<string>("")
  const [deleteProductName, setDeleteProductName] = useState<string>("")

  const [deleteCategoryName, setDeleteCategoryName] = useState<string>("")

  const sortedProducts = useMemo(() => {
  const arr = [...a.data.products]
  const dir = sort.dir === "asc" ? 1 : -1

  arr.sort((x, y) => {
    if (sort.key === "createdAt") {
      return ((x.createdAt ?? 0) - (y.createdAt ?? 0)) * dir
    }

    if (sort.key === "active") {
      const ax = Boolean(x.active)
      const ay = Boolean(y.active)
      if (ax === ay) return 0
      return (ax ? 1 : -1) * dir
    }

    if (sort.key === "category") {
      const cx = (x.category ?? "미분류").trim() || "미분류"
      const cy = (y.category ?? "미분류").trim() || "미분류"
      const cmp = cx.localeCompare(cy, "ko")
      if (cmp !== 0) return cmp * dir
      return x.name.localeCompare(y.name, "ko") * dir
    }

    // name
    return x.name.localeCompare(y.name, "ko") * dir
  })

  return arr
}, [a.data.products, sort])

const toggleSort = (key: "createdAt" | "name" | "category" | "active") => {
  setSort((prev) => {
    if (prev.key !== key) return { key, dir: "asc" }
    return { key, dir: prev.dir === "asc" ? "desc" : "asc" }
  })
}

const sortIndicator = (key: "createdAt" | "name" | "category" | "active") => {
  if (sort.key !== key) return null
  return <span className="text-muted-foreground">{sort.dir === "asc" ? "▲" : "▼"}</span>
}

  const filteredProducts = useMemo(() => {
    if (productListCategory === "all") return sortedProducts
    if (productListCategory === "uncategorized") {
      return sortedProducts.filter((p) => !p.category)
    }
    return sortedProducts.filter((p) => (p.category ?? "") === productListCategory)
  }, [sortedProducts, productListCategory])

  const searchedProducts = useMemo(() => {
    const q = query.trim().toLowerCase()
    if (!q) return filteredProducts
    return filteredProducts.filter((p) => (p.name ?? "").toLowerCase().includes(q))
  }, [filteredProducts, query])

  const totalPages = Math.max(1, Math.ceil(searchedProducts.length / ITEMS_PER_PAGE))
  const safePage = Math.min(productListPage, totalPages)
  const pagedProducts = useMemo(() => {
    const start = (safePage - 1) * ITEMS_PER_PAGE
    return searchedProducts.slice(start, start + ITEMS_PER_PAGE)
  }, [searchedProducts, safePage])

  const safeProducts = pagedProducts

  // 페이지/필터 변경 시 보정
  if (safePage !== productListPage) setProductListPage(safePage)

  if (a.errorMsg) return <ErrorState message={a.errorMsg} onRetry={a.refresh} />

  return (
    <div className="space-y-6">
      {a.loading && <div className="text-sm text-muted-foreground">동기화 중…</div>}

      <AppCard
        density="compact"
        title="제품 추가"
        action={
          <div className="flex flex-wrap items-center gap-2">
            <AppButton type="button" variant="outline" onClick={a.handleProductCsvUpload}>
              CSV 템플릿 다운로드
            </AppButton>

            <AppButton
              type="button"
              variant="outline"
              onClick={() => a.csvInputRef.current?.click()}
              disabled={a.loading || a.csvBusy}
            >
              CSV로 제품 일괄 추가/업데이트
            </AppButton>

            <input
              ref={a.csvInputRef}
              type="file"
              accept=".csv"
              className="hidden"
              onChange={a.onChangeProductCsv}
            />
          </div>
        }
        className="min-w-0"
        contentClassName="space-y-3"
      >
        <div className="flex flex-wrap items-center gap-2 min-w-0">
          <Popover
            open={a.categoryOpen}
            onOpenChange={(open) => {
              a.setCategoryOpen(open)
              if (!open) a.setCategoryTyped(false)
            }}
          >
            <div className="flex-[1_1_180px] min-w-[160px] max-w-[240px]">
              <PopoverTrigger asChild>
                <AppButton type="button" variant="outline" className="w-full justify-between font-normal">
                  <span className="truncate">{a.newCategory.trim() ? a.newCategory : "카테고리 입력/선택"}</span>
                  <span className="text-muted-foreground">▾</span>
                </AppButton>
              </PopoverTrigger>

              <PopoverContent align="start" className="p-0 w-[--radix-popover-trigger-width]">
                <Command>
                  <CommandInput
                    placeholder="카테고리 검색/입력..."
                    value={a.newCategory}
                    onValueChange={(v) => {
                      a.setCategoryTyped(true)
                      a.setNewCategory(v)
                    }}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        e.preventDefault()
                        a.saveCategoryOnly()
                      }
                    }}
                  />
                  <CommandList>
                    <CommandEmpty>
                      <div className="px-2 py-2 text-sm text-muted-foreground">
                        검색 결과가 없습니다.
                        {a.newCategory.trim() ? " Enter로 새 카테고리를 저장할 수 있어요." : ""}
                      </div>
                    </CommandEmpty>

                    <CommandGroup>
                      {a.categoryOptions
                        .filter((c) => {
                          const q = a.newCategory.trim()
                          if (!q) return true
                          return c.includes(q)
                        })
                        .map((c) => (
                          <CommandItem
                            key={c}
                            value={c}
                            onSelect={() => {
                              a.setCategoryTyped(false)
                              a.setNewCategory(c)
                              a.setCategoryOpen(false)
                            }}
                            className="flex items-center justify-between"
                          >
                            <span className="truncate">{c}</span>
                            <AppButton
                              type="button"
                              variant="ghost"
                              size="icon-sm"
                              className="text-destructive"
                              onClick={(e) => {
                                e.preventDefault()
                                e.stopPropagation()
                                setDeleteCategoryName(c)
                              }}
                              title="카테고리 삭제"
                            >
                              ×
                            </AppButton>
                          </CommandItem>
                        ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>

              {a.isExistingCategory && a.categoryTyped && (
                <div className="mt-1 text-xs text-muted-foreground select-none">이미 존재하는 카테고리입니다</div>
              )}
            </div>
          </Popover>

          <AppInput
            id="product-name-input"
            className="flex-[2_1_220px] min-w-0"
            value={a.newProductName}
            onChange={(e) => a.setNewProductName(e.target.value)}
            placeholder="예: 미드나잇블루"
            onKeyDown={(e) => {
              if (e.key === "Enter") a.addProduct()
            }}
          />

          <AppButton className="flex-shrink-0 whitespace-nowrap" onClick={a.addProduct} disabled={a.loading}>
            추가
          </AppButton>
        </div>
      </AppCard>

      <AppCard density="compact" title="제품 목록" className="min-w-0" contentClassName="space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs text-muted-foreground">카테고리:</span>

          <AppSelect
            value={productListCategory}
            onValueChange={(v) => {
              setProductListCategory(v)
              setProductListPage(1)
            }}
            options={[
              { value: "all", label: "전체" },
              { value: "uncategorized", label: "미분류" },
              ...a.categoryOptions.map((c) => ({ value: c, label: c })),
            ]}
            className="w-[220px]"
          />

          <AppInput
            value={query}
            onChange={(e) => {
              setQuery(e.target.value)
              setProductListPage(1)
            }}
            placeholder="제품명 검색"
            className="w-[220px]"
          />

          <div className="ml-auto text-xs text-muted-foreground">
            {searchedProducts.length}개 중 {safeProducts.length}개 표시
          </div>
        </div>

        {a.loading ? (
          <div className="space-y-2">
            {Array.from({ length: 6 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : safeProducts.length === 0 ? (
          <EmptyState
            title="표시할 제품이 없습니다"
            description={productListCategory === "all" ? "먼저 제품을 추가하거나 CSV로 업로드하세요." : "다른 카테고리를 선택하거나 제품을 추가하세요."}
            action={
              <AppButton
                type="button"
                onClick={() => {
                  const el = document.getElementById("product-name-input") as HTMLInputElement | null
                  el?.focus()
                }}
              >
                제품 추가로 이동
              </AppButton>
            }
          />
        ) : (
          <>
            <div className="overflow-x-auto rounded-xl border">
              <Table>
                <TableHeader>
                  <TableRow>
  <TableHead className="min-w-[320px]">
  <button type="button" onClick={() => toggleSort("name")} className="inline-flex items-center gap-1">
    제품명 {sortIndicator("name")}
  </button>
</TableHead>
<TableHead className="w-[180px]">
  <button type="button" onClick={() => toggleSort("active")} className="inline-flex items-center gap-1">
    상태 {sortIndicator("active")}
  </button>
</TableHead>
<TableHead className="w-[140px] text-right">작업</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  {safeProducts.map((p) => {
                    const isEditing = a.editingProductId === p.id

                    return (
                      <TableRow key={p.id}>
                        <TableCell className="align-top">
                          {isEditing ? (
                            <div className="flex flex-col gap-2">
                              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
                                <AppInput
                                  value={a.editingProductName}
                                  onChange={(e) => a.setEditingProductName(e.target.value)}
                                  placeholder="제품명"
                                />
                                <AppSelect
                                  value={a.editingProductCategory || ""}
                                  onValueChange={(v) => a.setEditingProductCategory(v)}
                                  options={[
                                    { value: "", label: "미분류" },
                                    ...a.categories.map((name) => ({ value: name, label: name })),
                                  ]}
                                />
                              </div>

                              <div className="flex items-center gap-2">
                                <AppButton
                                  type="button"
                                  variant="outline"
                                  size="sm"
                                  onClick={() => {
                                    a.setEditingProductName(a.editingOriginalRef.current)
                                    a.setEditingProductCategory(a.editingOriginalCategoryRef.current)
                                    a.setEditingProductId(null)
                                  }}
                                >
                                  취소
                                </AppButton>

                                <AppButton
                                  type="button"
                                  size="sm"
                                  onClick={async () => {
                                    await a.saveProductFieldsSimple(p.id, a.editingProductName, a.editingProductCategory)
                                    a.setEditingProductId(null)
                                  }}
                                >
                                  저장
                                </AppButton>
                              </div>
                            </div>
                          ) : (
                            <div className="min-w-0">
                              <div className="flex items-center gap-2 min-w-0">
                                <div className="truncate text-sm font-medium">{p.name}</div>
                                <AppBadge variant="outline" className="shrink-0">
                                  {p.category ? p.category : "미분류"}
                                </AppBadge>
                                {p.makeEnabled === false ? (
                                  <AppBadge variant="secondary" className="shrink-0">
                                    제작중지
                                  </AppBadge>
                                ) : null}
                              </div>
                            </div>
                          )}
                        </TableCell>

                        <TableCell className="align-top">
                          <div className="flex flex-col gap-2">
                            <div className="flex flex-wrap items-center justify-end gap-4">
                            <div className="flex items-center gap-2">
                              <AppSwitch
                                checked={Boolean(p.active)}
                                onCheckedChange={(v) => {
                                  const next = Boolean(v)
                                  if (next !== Boolean(p.active)) a.toggleProductActiveFlip(p.id)
                                }}
                                disabled={a.loading}
                              />
                              <span className="text-xs text-muted-foreground select-none">{p.active ? "판매중" : "비활성"}</span>
                            </div>

                            <div className="flex items-center gap-2">
                              <AppSwitch
                                checked={p.makeEnabled !== false}
                                onCheckedChange={(v) => {
                                  const next = Boolean(v)
                                  const cur = p.makeEnabled !== false
                                  if (next !== cur) a.toggleProductMakeEnabledFlip(p.id)
                                }}
                                disabled={a.loading}
                              />
                              <span className="text-xs text-muted-foreground select-none">제작대상</span>
                            </div>
                          </div>
                          </div>
                        </TableCell>

                        <TableCell className="align-top">
                          <div className="flex justify-end gap-2">
                            {!isEditing ? (
                              <AppButton
                                type="button"
                                variant="outline"
                                size="sm"
                                onClick={() => {
                                  a.setEditingProductId(p.id)
                                  a.setEditingProductName(p.name)
                                  a.editingOriginalRef.current = p.name
                                  a.setEditingProductCategory(p.category ?? "")
                                  a.editingOriginalCategoryRef.current = p.category ?? ""
                                }}
                              >
                                수정
                              </AppButton>
                            ) : null}

                            <AppButton
                              type="button"
                              variant="destructive"
                              size="sm"
                              onClick={() => { setDeleteProductId(p.id); setDeleteProductName(p.name); }}
                              disabled={a.loading}
                            >
                              삭제
                            </AppButton>
                          </div>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </div>

            {totalPages > 1 && (
              <div className="flex flex-wrap justify-center gap-2 pt-2">
                {Array.from({ length: totalPages }).map((_, idx) => {
                  const pageNum = idx + 1
                  const active = pageNum === safePage
                  return (
                    <AppButton
                      key={pageNum}
                      type="button"
                      size="sm"
                      variant={active ? "default" : "outline"}
                      onClick={() => setProductListPage(pageNum)}
                    >
                      {pageNum}
                    </AppButton>
                  )
                })}
              </div>
            )}
          </>
        )}
      </AppCard>
    
      <ConfirmDialog
        open={Boolean(deleteProductId)}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteProductId("")
            setDeleteProductName("")
          }
        }}
        title="제품을 삭제할까요?"
        description={deleteProductName ? `“${deleteProductName}” 제품이 삭제됩니다. 되돌릴 수 없습니다.` : "제품이 삭제됩니다. 되돌릴 수 없습니다."}
        confirmText="삭제"
        cancelText="취소"
        destructive
        busy={a.loading}
        onConfirm={async () => {
          const id = deleteProductId
          if (!id) return
          try {
            await a.deleteProduct(id)
          } catch {
            toast.error("삭제에 실패했어요.")
          } finally {
            setDeleteProductId("")
            setDeleteProductName("")
          }
        }}
      />

      <ConfirmDialog
        open={Boolean(deleteCategoryName)}
        onOpenChange={(open) => {
          if (!open) setDeleteCategoryName("")
        }}
        title="카테고리를 삭제할까요?"
        description={
          deleteCategoryName
            ? `“${deleteCategoryName}” 카테고리가 삭제됩니다. (제품의 카테고리 값은 유지됩니다)`
            : "카테고리가 삭제됩니다. (제품의 카테고리 값은 유지됩니다)"
        }
        confirmText="삭제"
        cancelText="취소"
        destructive
        busy={a.loading}
        onConfirm={async () => {
          const name = deleteCategoryName
          if (!name) return
          await a.deleteCategory(name)
          setDeleteCategoryName("")
        }}
      />
</div>
  )
}
