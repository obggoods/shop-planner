// src/features/stores/components/StoresManager.tsx
import { useCallback, useMemo, useState } from "react"
import type { Product } from "@/data/models"

import { AppButton } from "@/components/app/AppButton"
import { AppCard } from "@/components/app/AppCard"
import { AppInput } from "@/components/app/AppInput"
import { AppSelect } from "@/components/app/AppSelect"
import { AppSwitch } from "@/components/app/AppSwitch"
import { AppBadge } from "@/components/app/AppBadge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

import { useAppData } from "@/features/core/useAppData"
import { ConfirmDialog } from "@/components/shared/ConfirmDialog"
import { toast } from "@/lib/toast"
import { EmptyState } from "@/components/shared/EmptyState"
import { Skeleton } from "@/components/shared/Skeleton"
import { ErrorState } from "@/components/shared/ErrorState"

export default function StoresManager() {
  const a = useAppData()

  const stores = useMemo(() => {
    return [...a.data.stores].sort((x, y) => (y.createdAt ?? 0) - (x.createdAt ?? 0))
  }, [a.data.stores])

  const products = useMemo(() => {
    return [...a.data.products].sort((x, y) => (y.createdAt ?? 0) - (x.createdAt ?? 0))
  }, [a.data.products])

  const [manageStoreId, setManageStoreId] = useState<string>("")
  const [openStoreCats, setOpenStoreCats] = useState<Record<string, boolean>>({})

  const [deleteStoreId, setDeleteStoreId] = useState<string>("")
  const [deleteStoreName, setDeleteStoreName] = useState<string>("")

  const [bulkToggle, setBulkToggle] = useState<{ storeId: string; next: boolean } | null>(null)

  const isEnabledInStore = useCallback(
    (storeId: string, productId: string) => {
      const hit = a.data.storeProductStates.find((x) => x.storeId === storeId && x.productId === productId)
      return hit ? hit.enabled : true
    },
    [a.data.storeProductStates]
  )

  if (a.errorMsg) return <ErrorState message={a.errorMsg} onRetry={a.refresh} />

  return (
    <div className="space-y-6">
      {a.loading && <div className="text-sm text-muted-foreground">동기화 중…</div>}

      <AppCard density="compact" title="입점처 추가" className="min-w-0">
        <div className="flex items-center gap-2">
          <AppInput
            id="store-name-input"
            className="flex-1"
            value={a.newStoreName}
            onChange={(e) => a.setNewStoreName(e.target.value)}
            placeholder="예: 홍대 A소품샵"
            onKeyDown={(e) => {
              if (e.key === "Enter") a.addStore()
            }}
          />

          <AppButton onClick={a.addStore} disabled={a.loading}>
            추가
          </AppButton>
        </div>
      </AppCard>

      <AppCard
        title="입점처별 취급 제품 설정"
        description="입점처마다 입고하는 제품이 다르면 여기서 ON/OFF로 관리해요. (OFF면 대시보드에서 숨김 + 제작 계산 제외)"
        className="mb-4"
        contentClassName="space-y-3"
      >
        {stores.length === 0 ? (
          <p className="text-sm text-muted-foreground">입점처가 없어. 먼저 입점처를 추가해줘.</p>
        ) : products.length === 0 ? (
          <p className="text-sm text-muted-foreground">제품이 없어. 먼저 제품을 추가해줘.</p>
        ) : (
          <div className="flex flex-wrap items-center gap-3">
            <AppSelect
              value={manageStoreId}
              onValueChange={(v) => setManageStoreId(v)}
              placeholder="(입점처 선택)"
              options={stores.map((s) => ({ value: s.id, label: s.name }))}
              className="min-w-[220px]"
            />

            {!manageStoreId ? (
              <span className="text-sm text-muted-foreground">입점처를 선택하면 제품 ON/OFF 목록이 보여.</span>
            ) : (
              <span className="text-sm font-semibold">선택됨: {stores.find((s) => s.id === manageStoreId)?.name}</span>
            )}
          </div>
        )}

        {!!manageStoreId && (
          <div className="mt-2 border-t border-border pt-3 space-y-3">
            <div className="flex flex-wrap gap-2">
              <AppButton
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setBulkToggle({ storeId: manageStoreId, next: true })}
                disabled={a.loading}
              >
                전체 ON
              </AppButton>
              <AppButton
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setBulkToggle({ storeId: manageStoreId, next: false })}
                disabled={a.loading}
              >
                전체 OFF
              </AppButton>
            </div>

            {(() => {
              const activeProducts = products.filter((p) => p.active)
              const groups = new Map<string, Product[]>()
              for (const p of activeProducts) {
                const cat = (p.category ?? "미분류").trim() || "미분류"
                const arr = groups.get(cat) ?? []
                arr.push(p)
                groups.set(cat, arr)
              }
              const cats = Array.from(groups.keys()).sort((x, y) => x.localeCompare(y, "ko"))

              return (
                <div className="space-y-3">
                  {cats.map((cat) => {
                    const list = groups.get(cat) ?? []
                    const sorted = [...list].sort((x, y) => x.name.localeCompare(y.name, "ko"))
                    const isOpen = openStoreCats[cat] ?? true
                    const onCount = sorted.reduce(
                      (acc, p) => (isEnabledInStore(manageStoreId, p.id) ? acc + 1 : acc),
                      0
                    )

                    return (
                      <div key={cat} className="rounded-xl border border-border bg-background overflow-hidden">
                        <button
                          type="button"
                          onClick={() =>
                            setOpenStoreCats((prev) => ({
                              ...prev,
                              [cat]: !(prev[cat] ?? true),
                            }))
                          }
                          className="w-full flex items-center justify-between gap-3 px-3 py-2 text-left bg-muted/30 hover:bg-muted/50"
                        >
                          <span className="text-sm font-semibold">
                            {cat}{" "}
                            <span className="text-xs text-muted-foreground font-medium">({onCount}/{sorted.length} ON)</span>
                          </span>
                          <span className="text-muted-foreground font-semibold">{isOpen ? "▾" : "▸"}</span>
                        </button>

                        {isOpen && (
                          <ul className="list-none m-0 p-0">
                            {sorted.map((p) => {
                              const enabled = isEnabledInStore(manageStoreId, p.id)
                              return (
                                <li
                                  key={p.id}
                                  className={`flex items-center justify-between gap-3 px-3 py-2 border-t border-border ${
                                    enabled ? "" : "opacity-50"
                                  }`}
                                >
                                  <div className="min-w-0">
                                    <div className="text-sm font-semibold truncate">{p.name}</div>
                                    <div className="text-xs text-muted-foreground">{enabled ? "ON (취급)" : "OFF (미취급)"}</div>
                                  </div>

                                  <div className="flex items-center gap-2">
                                  <AppSwitch
                                    checked={enabled}
                                    onCheckedChange={(v) => a.toggleOne(manageStoreId, p.id, Boolean(v))}
                                    disabled={a.loading}
                                  />
                                  <span className="text-xs text-muted-foreground">{enabled ? "취급" : "미취급"}</span>
                                </div>
                                </li>
                              )
                            })}
                          </ul>
                        )}
                      </div>
                    )
                  })}
                </div>
              )
            })()}
          </div>
        )}
      </AppCard>

      <AppCard density="compact" title="입점처 목록" className="min-w-0" contentClassName="space-y-3">
        {a.loading ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : stores.length === 0 ? (
          <EmptyState
            title="입점처가 없습니다"
            description="먼저 입점처를 추가하세요."
            action={
              <AppButton
                type="button"
                onClick={() => {
                  const el = document.getElementById("store-name-input") as HTMLInputElement | null
                  el?.focus()
                }}
              >
                입점처 추가로 이동
              </AppButton>
            }
          />
        ) : (
          <div className="overflow-x-auto rounded-xl border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead className="min-w-[240px]">입점처</TableHead>
                  <TableHead className="w-[140px] text-right">작업</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {stores.map((s) => (
                  <TableRow key={s.id}>
                    <TableCell>
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="text-sm font-medium truncate">{s.name}</div>
                        <AppBadge variant="muted" className="shrink-0">
                          {
                            a.data.storeProductStates.filter((sp) => sp.storeId === s.id && sp.enabled).length
                          }/
                          {a.data.products.length}
                        </AppBadge>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end">
                        <AppButton type="button" size="sm" variant="destructive" onClick={() => { setDeleteStoreId(s.id); setDeleteStoreName(s.name); }}>
                          삭제
                        </AppButton>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </AppCard>
    
      <ConfirmDialog
        open={Boolean(deleteStoreId)}
        onOpenChange={(open) => {
          if (!open) {
            setDeleteStoreId("")
            setDeleteStoreName("")
          }
        }}
        title="입점처를 삭제할까요?"
        description={deleteStoreName ? `“${deleteStoreName}” 입점처가 삭제됩니다. 되돌릴 수 없습니다.` : "입점처가 삭제됩니다. 되돌릴 수 없습니다."}
        confirmText="삭제"
        cancelText="취소"
        destructive
        busy={a.loading}
        onConfirm={async () => {
          const id = deleteStoreId
          if (!id) return
          try {
            await a.deleteStore(id)
          } catch {
            toast.error("삭제에 실패했어요.")
          } finally {
            setDeleteStoreId("")
            setDeleteStoreName("")
          }
        }}
      />

      <ConfirmDialog
        open={Boolean(bulkToggle)}
        onOpenChange={(open) => {
          if (!open) setBulkToggle(null)
        }}
        title={bulkToggle?.next ? "전체 ON을 적용할까요?" : "전체 OFF를 적용할까요?"}
        description={
          bulkToggle?.next
            ? "선택한 입점처의 모든 제품을 ON(취급)으로 설정합니다."
            : "선택한 입점처의 모든 제품을 OFF(미취급)으로 설정합니다."
        }
        confirmText={bulkToggle?.next ? "전체 ON" : "전체 OFF"}
        cancelText="취소"
        destructive={!bulkToggle?.next}
        busy={a.loading}
        onConfirm={async () => {
          if (!bulkToggle) return
          try {
            await a.toggleAll(bulkToggle.storeId, bulkToggle.next)
            toast.success(bulkToggle.next ? "전체 ON을 적용했어요." : "전체 OFF를 적용했어요.")
          } catch {
            toast.error("일괄 변경에 실패했어요.")
          } finally {
            setBulkToggle(null)
          }
        }}
      />
</div>
  )
}
