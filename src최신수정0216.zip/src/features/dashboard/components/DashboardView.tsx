// src/features/dashboard/components/DashboardView.tsx
import { Fragment, useCallback, useEffect, useMemo, useRef, useState } from "react"

import { useAppData } from "@/features/core/useAppData"
import { upsertInventoryItemDB } from "@/data/store.supabase"
import type { ReactNode } from "react"
import { AppCard } from "@/components/app/AppCard"
import { AppBadge } from "@/components/app/AppBadge"
import { AppButton } from "@/components/app/AppButton"
import { AppSelect } from "@/components/app/AppSelect"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

import { EmptyState } from "@/components/shared/EmptyState"
import { Skeleton } from "@/components/shared/Skeleton"
import { ErrorState } from "@/components/shared/ErrorState"

function toInt(v: string, fallback: number) {
  const n = Number.parseInt((v ?? "").trim(), 10)
  return Number.isFinite(n) ? n : fallback
}

function safeFilename(name: string) {
  return String(name ?? "").replace(/[\\\/:*?"<>|]/g, "_").trim()
}

// -----------------------------
// 📥 CSV 다운로드 유틸
// -----------------------------
function downloadCSV(filename: string, rows: string[][]) {
  const csvContent = rows
    .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
    .join("\n")

  const BOM = "\uFEFF"
  const blob = new Blob([BOM + csvContent], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)

  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function KpiCard(props: {
  label: string
  value: string
  helper?: string
  badge?: ReactNode
}) {
  return (
    <AppCard
      density="compact"
      title={
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span>{props.label}</span>
            {props.badge ?? null}
          </div>
        </div>
      }
      description={props.helper}
      className="h-full"
    >
      <div className="text-2xl font-semibold tracking-tight">{props.value}</div>
    </AppCard>
  )
}

export default function DashboardView() {
  const a = useAppData()

  // 탭: 요약 / 재고현황 / 제작리스트
  const [tab, setTab] = useState<"overview" | "inventory" | "make">("overview")

  // 필터/선택
  const [selectedStoreId, setSelectedStoreId] = useState<string>("")
  const [categoryFilter, setCategoryFilter] = useState<string>("all")
  const [showOffProducts, setShowOffProducts] = useState(false)

  // ✅ 재고 입력: 빈칸 입력 허용을 위해 string으로 관리
  const [qtyDraft, setQtyDraft] = useState<Record<string, string>>({})

  // ✅ 저장 상태 표시
  const [saveState, setSaveState] = useState<"idle" | "saving" | "saved" | "error">("idle")

  // ✅ 키보드 이동용 input refs
  const inputRefs = useRef<Record<string, HTMLInputElement | null>>({})

  const lowStockThreshold = useMemo(() => toInt(a.lowStockThresholdInput, 2), [a.lowStockThresholdInput])
  const targetQty = useMemo(() => toInt(a.defaultTargetQtyInput, 5), [a.defaultTargetQtyInput])

  // store map
  const storeById = useMemo(() => new Map(a.data.stores.map((s) => [s.id, s])), [a.data.stores])

  // 카테고리 옵션
  const categories = useMemo(() => {
    const set = new Set<string>()
    a.data.products.forEach((p: any) => {
      const c = (p.category ?? p.categoryName ?? "").toString().trim()
      if (c) set.add(c)
    })
    return Array.from(set).sort((x, y) => x.localeCompare(y, "ko"))
  }, [a.data.products])

  // 입점처 옵션(AppSelect)
  const stores = useMemo(() => {
    return (a.data.stores ?? [])
      .map((s: any) => ({
        id: (s.id ?? "").toString(),
        name: (s.name ?? s.storeName ?? s.title ?? "").toString().trim(),
      }))
      .filter((s) => s.id && s.name)
      .sort((x, y) => x.name.localeCompare(y.name, "ko"))
  }, [a.data.stores])

  // 최초 1회: 입점처 기본 선택
  useEffect(() => {
    if (!selectedStoreId && stores.length > 0) setSelectedStoreId(stores[0].id)
  }, [stores, selectedStoreId])

  // enabled 상태 인덱스
  const enabledPairSet = useMemo(() => {
    const m = new Map<string, boolean>()
    for (const x of a.data.storeProductStates) {
      m.set(`${x.storeId}::${x.productId}`, x.enabled)
    }
    return m
  }, [a.data.storeProductStates])

  // inventory 인덱스
  const invIndex = useMemo(() => {
    const m = new Map<string, number>()
    for (const it of a.data.inventory) {
      m.set(`${it.storeId}::${it.productId}`, it.onHandQty)
    }
    return m
  }, [a.data.inventory])

  const getOnHand = useCallback(
    (storeId: string, productId: string) => invIndex.get(`${storeId}::${productId}`) ?? 0,
    [invIndex]
  )

  // ✅ 재고 저장 디바운스
  const invSaveTimers = useRef<Record<string, number>>({})
  const scheduleInventorySave = useCallback((storeId: string, productId: string, qty: number) => {
    const key = `${storeId}__${productId}`
    const prev = invSaveTimers.current[key]
    if (prev) window.clearTimeout(prev)

    setSaveState("saving")

    invSaveTimers.current[key] = window.setTimeout(async () => {
      try {
        await upsertInventoryItemDB({ storeId, productId, onHandQty: qty })
        setSaveState("saved")
        window.setTimeout(() => setSaveState("idle"), 900)
      } catch (e) {
        console.error(e)
        setSaveState("error")
        window.setTimeout(() => setSaveState("idle"), 1400)
      }
    }, 400)
  }, [])

  // 활성 제품 정렬
  const activeProducts = useMemo(() => {
    return [...a.data.products]
      .filter((p) => p.active)
      .sort((x, y) => {
        const c = (x.category ?? "").localeCompare(y.category ?? "", "ko")
        if (c !== 0) return c
        return x.name.localeCompare(y.name, "ko")
      })
  }, [a.data.products])

  // ✅ 선택 입점처에서 보일 제품(ON 제품 + (옵션) OFF 제품)
  const productsForStore = useMemo(() => {
    if (!selectedStoreId) return []
    const enabled: typeof activeProducts = []
    const disabled: typeof activeProducts = []

    for (const p of activeProducts) {
      const enabledInStore = enabledPairSet.get(`${selectedStoreId}::${p.id}`) ?? true
      ;(enabledInStore ? enabled : disabled).push(p)
    }

    return showOffProducts ? [...enabled, ...disabled] : [...enabled]
  }, [activeProducts, selectedStoreId, enabledPairSet, showOffProducts])

  // ✅ 재고현황 rows (전체 제품)
  const inventoryRows = useMemo(() => {
    if (!selectedStoreId) return []
    return productsForStore
      .filter((p) => {
        const pc = (p.category ?? "").toString().trim()
        if (categoryFilter !== "all" && pc !== categoryFilter) return false
        return true
      })
      .map((p) => {
        const enabledInStore = enabledPairSet.get(`${selectedStoreId}::${p.id}`) ?? true
        const onHand = getOnHand(selectedStoreId, p.id)
        const need = Math.max(0, targetQty - onHand)
        const isLow = onHand < lowStockThreshold
        return { product: p, enabledInStore, onHand, need, isLow }
      })
  }, [
    selectedStoreId,
    productsForStore,
    categoryFilter,
    enabledPairSet,
    getOnHand,
    targetQty,
    lowStockThreshold,
  ])

  // ✅ 현재 표에 표시되는 값으로 qtyDraft 초기화/동기화
  useEffect(() => {
    if (!selectedStoreId) return
    const next: Record<string, string> = {}
    for (const r of inventoryRows) {
      next[r.product.id] = String(r.onHand)
    }
    setQtyDraft(next)
  }, [selectedStoreId, inventoryRows])

  // ✅ 카테고리(품목)별로 그룹핑된 재고 rows
  const inventoryGrouped = useMemo(() => {
    const map = new Map<string, typeof inventoryRows>()
    for (const r of inventoryRows) {
      const key = (r.product.category ?? "미분류").toString().trim() || "미분류"
      const arr = map.get(key) ?? []
      arr.push(r)
      map.set(key, arr)
    }

    const keys = Array.from(map.keys()).sort((a, b) => a.localeCompare(b, "ko"))
    return keys.map((category) => ({
      category,
      rows: map.get(category)!,
    }))
  }, [inventoryRows])

  // ✅ 키보드 이동을 위한 현재 표의 순서(위→아래)
  const inventoryOrder = useMemo(() => inventoryRows.map((r) => r.product.id), [inventoryRows])

  const focusRow = (productId: string) => {
    const el = inputRefs.current[productId]
    if (el) {
      el.focus()
      el.select()
    }
  }

  // React 타입 의존 없게 any 사용(프로젝트 strict unused 이슈 방지)
  const handleQtyKeyDown = (e: any, productId: string) => {
    if (e.key !== "Enter" && e.key !== "ArrowDown" && e.key !== "ArrowUp") return

    e.preventDefault()
    const idx = inventoryOrder.indexOf(productId)
    if (idx < 0) return

    if (e.key === "ArrowUp") {
      const prevId = inventoryOrder[Math.max(0, idx - 1)]
      focusRow(prevId)
      return
    }

    const nextId = inventoryOrder[Math.min(inventoryOrder.length - 1, idx + 1)]
    focusRow(nextId)
  }

  const commitQty = (productId: string, raw: string) => {
    const nextQty = raw.trim() === "" ? 0 : Number(raw)
    const safe = Number.isFinite(nextQty) ? Math.max(0, Math.floor(nextQty)) : 0

    // draft 정규화(표시는 정수)
    setQtyDraft((prev) => ({ ...prev, [productId]: String(safe) }))

    // DB 저장(디바운스)
    scheduleInventorySave(selectedStoreId, productId, safe)
  }

  // ✅ 부족분 제작 리스트 rows (저재고만)
  const makeRows = useMemo(() => {
    if (!selectedStoreId) return []
    return productsForStore
      .filter((p) => p.makeEnabled !== false)
      .map((p) => {
        const enabledInStore = enabledPairSet.get(`${selectedStoreId}::${p.id}`) ?? true
        if (!enabledInStore) return null
        const onHand = getOnHand(selectedStoreId, p.id)
        if (onHand >= lowStockThreshold) return null
        const need = Math.max(0, targetQty - onHand)
        if (need <= 0) return null
        return { product: p, onHand, need }
      })
      .filter(Boolean) as Array<{ product: (typeof activeProducts)[number]; onHand: number; need: number }>
  }, [selectedStoreId, productsForStore, enabledPairSet, getOnHand, lowStockThreshold, targetQty])

  // KPI
  const kpi = useMemo(() => {
    const productsTotal = a.data.products.length
    const productsActive = a.data.products.filter((p) => p.active).length
    const storesTotal = a.data.stores.length

    let lowStockPairs = 0
    for (const s of a.data.stores) {
      for (const p of a.data.products) {
        if (!p.active) continue
        const enabled = enabledPairSet.get(`${s.id}::${p.id}`) ?? true
        if (!enabled) continue
        const onHand = invIndex.get(`${s.id}::${p.id}`) ?? 0
        if (onHand < lowStockThreshold) lowStockPairs += 1
      }
    }

    return { productsTotal, productsActive, storesTotal, lowStockPairs }
  }, [a.data.products, a.data.stores, enabledPairSet, invIndex, lowStockThreshold])

  // -----------------------------
  // 📥 다운로드 버튼(요청한 2개)
  // -----------------------------
  const exportInventoryCSV = useCallback(() => {
    if (!selectedStoreId) return
    const store = storeById.get(selectedStoreId)
    const today = new Date().toISOString().slice(0, 10)

    const rows: string[][] = []
    rows.push(["입점처", "품목", "제품", "현재 재고"])

    for (const r of inventoryRows) {
      rows.push([store?.name ?? "-", r.product.category ?? "-", r.product.name, String(r.onHand)])
    }

    const storeSafe = safeFilename(store?.name ?? "store")
    downloadCSV(`ShopPlanner_재고현황_${storeSafe}_${today}.csv`, rows)
  }, [selectedStoreId, storeById, inventoryRows])

  const exportMakeCSV = useCallback(() => {
    if (!selectedStoreId) return
    const store = storeById.get(selectedStoreId)
    const today = new Date().toISOString().slice(0, 10)

    const rows: string[][] = []
    rows.push(["입점처", "품목", "제품", "현재 재고", "목표 재고", "필요 수량"])

    for (const r of makeRows) {
      rows.push([store?.name ?? "-", r.product.category ?? "-", r.product.name, String(r.onHand), String(targetQty), String(r.need)])
    }

    const storeSafe = safeFilename(store?.name ?? "store")
    downloadCSV(`ShopPlanner_제작리스트_${storeSafe}_${today}.csv`, rows)
  }, [selectedStoreId, storeById, makeRows, targetQty])

  // 상태 처리
  if (a.errorMsg) return <ErrorState message={a.errorMsg} onRetry={a.refresh} />
  if (a.loading) return <Skeleton />
  if (a.data.stores.length === 0 || a.data.products.length === 0) {
    return (
      <EmptyState
        title="대시보드 데이터를 만들기 시작해요"
        description="입점처와 제품을 먼저 추가하면 KPI와 재고 현황이 표시됩니다."
      />
    )
  }

  return (
    <div className="space-y-6">
      {/* 상단: 다운로드 + 입점처 선택 */}
      <AppCard
        density="compact"
        title="대시보드"
        description="입점처별 재고 현황과 부족분 제작 리스트를 확인합니다."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <AppSelect
              value={selectedStoreId}
              onValueChange={setSelectedStoreId}
              placeholder="입점처 선택"
              options={stores.map((s) => ({ label: s.name, value: s.id }))}
            />

            <AppButton variant="secondary" onClick={exportInventoryCSV}>
              재고 현황 다운로드
            </AppButton>

            <AppButton variant="secondary" onClick={exportMakeCSV}>
              제작 리스트 다운로드
            </AppButton>
          </div>
        }
      >
        {/* KPI */}
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <KpiCard label="총 제품" value={`${kpi.productsTotal}`} />
          <KpiCard label="활성 제품" value={`${kpi.productsActive}`} helper="현재 판매/관리 대상" />
          <KpiCard label="입점처" value={`${kpi.storesTotal}`} />
          <KpiCard
            label="저재고 SKU"
            value={`${kpi.lowStockPairs}`}
            helper={`기준: ${lowStockThreshold} 미만`}
            badge={
              kpi.lowStockPairs > 0 ? (
                <AppBadge variant="destructive">주의</AppBadge>
              ) : (
                <AppBadge variant="secondary">정상</AppBadge>
              )
            }
          />
        </div>
      </AppCard>

      {/* 탭 */}
      <Tabs value={tab} onValueChange={(v) => setTab(v as any)}>
        <TabsList>
          <TabsTrigger value="overview">요약</TabsTrigger>
          <TabsTrigger value="inventory">재고 현황</TabsTrigger>
          <TabsTrigger value="make">
            제작 리스트
            {makeRows.length > 0 ? (
              <AppBadge className="ml-1" variant="destructive">
                {makeRows.length}
              </AppBadge>
            ) : null}
          </TabsTrigger>
        </TabsList>

        {/* 요약 탭 */}
        <TabsContent value="overview" className="space-y-6">
          <AppCard
            title="선택 입점처: 저재고 상위"
            description={`기준: ${lowStockThreshold} 미만 / 목표: ${targetQty}`}
            action={
              <AppButton variant="secondary" onClick={() => setTab("make")}>
                부족분 보기
              </AppButton>
            }
          >
            {makeRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">저재고 항목이 없습니다.</div>
            ) : (
              <Table className="table-fixed w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-40">품목</TableHead>
                    <TableHead className="w-[360px]">제품</TableHead>
                    <TableHead className="w-28 text-right">보유</TableHead>
                    <TableHead className="w-20 text-right">필요</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {makeRows.slice(0, 10).map((r) => (
                    <TableRow key={r.product.id}>
                      <TableCell className="w-40 font-medium">{r.product.category ?? "-"}</TableCell>
                      <TableCell className="w-[360px]">{r.product.name}</TableCell>
                      <TableCell className="w-28 text-right">{r.onHand}</TableCell>
                      <TableCell className="w-20 text-right">{r.need}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </AppCard>
        </TabsContent>

        {/* 재고 현황 탭 */}
        <TabsContent value="inventory" className="space-y-4">
          <div className="flex flex-wrap items-center gap-3">
            <AppSelect
              value={categoryFilter}
              onValueChange={setCategoryFilter}
              placeholder="전체 카테고리"
              options={[
                { label: "전체", value: "all" },
                ...categories.map((c) => ({ label: c, value: c })),
              ]}
            />

            <AppButton variant="secondary" onClick={() => setShowOffProducts((v) => !v)}>
              {showOffProducts ? "OFF 제품 숨기기" : "OFF 제품 포함"}
            </AppButton>

            <div className="text-xs text-muted-foreground flex items-center gap-2">
              <span>입력값은 자동 저장됩니다.</span>

              {saveState === "saving" ? <span className="rounded px-2 py-0.5 bg-muted">저장 중…</span> : null}

              {saveState === "saved" ? (
                <span className="rounded px-2 py-0.5 bg-emerald-500/10 text-emerald-700 dark:text-emerald-300">
                  저장됨
                </span>
              ) : null}

              {saveState === "error" ? (
                <span className="rounded px-2 py-0.5 bg-destructive/10 text-destructive">저장 실패</span>
              ) : null}
            </div>
          </div>

          <AppCard title="입점처별 제품 목록 및 재고 현황" description="엑셀처럼 재고를 수정할 수 있습니다. (Enter/↑↓ 이동)">
            {inventoryRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">표시할 항목이 없습니다.</div>
            ) : (
              <Table className="table-fixed w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-40">품목</TableHead>
                    <TableHead className="w-[360px]">제품</TableHead>
                    <TableHead className="w-28 text-right">현재</TableHead>
                    <TableHead className="w-20 text-right">목표</TableHead>
                    <TableHead className="w-20 text-right">필요</TableHead>
                  </TableRow>
                </TableHeader>

                <TableBody>
                  {inventoryGrouped.map((group) => (
                    <Fragment key={group.category}>
                      {/* 그룹 헤더 row */}
                      <TableRow className="bg-muted/40">
                        <TableCell colSpan={5} className="py-2">
                          <div className="flex items-center justify-between">
                            <div className="font-medium">{group.category}</div>
                            <div className="text-xs text-muted-foreground">{group.rows.length}개</div>
                          </div>
                        </TableCell>
                      </TableRow>

                      {/* 그룹 내부 rows */}
                      {group.rows.map((r) => {
                        const disabled = !r.enabledInStore

                        const display = qtyDraft[r.product.id] ?? String(r.onHand)

                        return (
                          <TableRow
                            key={r.product.id}
                            className={[
                              disabled ? "opacity-50" : "",
                              r.isLow && !disabled ? "bg-destructive/5" : "",
                            ].join(" ")}
                          >
                            <TableCell className="w-40 font-medium">{r.product.category ?? "-"}</TableCell>
                            <TableCell className="w-[360px]">{r.product.name}</TableCell>

                            <TableCell className="w-28 text-right">
                              <input
                                ref={(el) => {
                                  inputRefs.current[r.product.id] = el
                                }}
                                className="h-9 w-24 rounded-md border bg-background px-3 text-sm text-right"
                                type="number"
                                inputMode="numeric"
                                disabled={disabled}
                                value={display}
                                onFocus={(e) => e.currentTarget.select()}
                                onWheel={(e) => (e.currentTarget as HTMLInputElement).blur()}
                                onKeyDown={(e) => handleQtyKeyDown(e, r.product.id)}
                                onChange={(e) => {
                                  // 빈칸 허용(입력 UX)
                                  const raw = e.target.value
                                  setQtyDraft((prev) => ({ ...prev, [r.product.id]: raw }))

                                  // 입력 중에도 즉시 저장하고 싶으면 여기서 커밋
                                  // (빈칸은 0으로 저장)
                                  commitQty(r.product.id, raw)
                                }}
                                onBlur={(e) => {
                                  commitQty(r.product.id, e.target.value)
                                }}
                              />
                            </TableCell>

                            <TableCell className="w-20 text-right">{targetQty}</TableCell>

                            <TableCell className="w-20 text-right">
                              {r.onHand < lowStockThreshold ? (
                                <span className="font-semibold">{r.need}</span>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </Fragment>
                  ))}
                </TableBody>
              </Table>
            )}
          </AppCard>

          <div className="text-xs text-muted-foreground">
            참고: “필요”는 저재고 기준({lowStockThreshold} 미만)일 때만 표시합니다.
          </div>
        </TabsContent>

        {/* 제작 리스트 탭 */}
        <TabsContent value="make" className="space-y-4">
          <AppCard title="부족한 재고 제작 리스트" description={`기준: ${lowStockThreshold} 미만 / 목표: ${targetQty}`}>
            {makeRows.length === 0 ? (
              <div className="text-sm text-muted-foreground">제작할 항목이 없습니다.</div>
            ) : (
              <Table className="table-fixed w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-40">품목</TableHead>
                    <TableHead className="w-[360px]">제품</TableHead>
                    <TableHead className="w-28 text-right">현재</TableHead>
                    <TableHead className="w-20 text-right">필요</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {makeRows.map((r) => (
                    <TableRow key={r.product.id}>
                      <TableCell className="w-40 font-medium">{r.product.category ?? "-"}</TableCell>
                      <TableCell className="w-[360px]">{r.product.name}</TableCell>
                      <TableCell className="w-28 text-right">{r.onHand}</TableCell>
                      <TableCell className="w-20 text-right font-semibold">{r.need}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </AppCard>
        </TabsContent>
      </Tabs>
    </div>
  )
}
