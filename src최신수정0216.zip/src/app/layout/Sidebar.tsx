import { NavLink } from "react-router-dom"
import { X } from "lucide-react"
import { Button } from "@/components/ui/button"

const navItems = [
  { to: "/dashboard", label: "대시보드" },
  { to: "/products", label: "제품" },
  { to: "/stores", label: "입점처" },
  { to: "/margin", label: "마진 계산기" },
  { to: "/settings", label: "설정" },
] as const

function cx(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ")
}

export default function Sidebar(props: {
  isAdmin: boolean
  mobileOpen: boolean
  onMobileClose: () => void
}) {
  const { isAdmin, mobileOpen, onMobileClose } = props

  const items = [
    ...navItems,
    ...(isAdmin ? [{ to: "/admin/invites", label: "관리자" } as const] : []),
  ]

  const linkClass = (isActive: boolean) =>
    cx(
      "block rounded-lg px-3 py-2 text-sm transition-colors",
      "hover:bg-accent hover:text-accent-foreground",
      isActive && "bg-accent text-accent-foreground"
    )

  return (
    <>
      {/* 데스크톱 사이드바 */}
      <aside className="hidden md:flex md:w-60 md:flex-col md:border-r md:bg-background">
        <div className="h-14 px-4 flex items-center border-b">
          <NavLink to="/dashboard" className="font-semibold text-sm">
            스톡앤메이크
          </NavLink>
        </div>

        <nav className="flex-1 p-2 space-y-1">
          {items.map((it) => (
            <NavLink
              key={it.to}
              to={it.to}
              className={({ isActive }) => linkClass(isActive)}
            >
              {it.label}
            </NavLink>
          ))}
        </nav>
      </aside>

      {/* 모바일 오버레이 사이드바 */}
      {mobileOpen ? (
        <div className="md:hidden fixed inset-0 z-50">
          {/* 배경(눌러서 닫기) */}
          <button
            type="button"
            className="absolute inset-0 bg-black/40"
            onClick={onMobileClose}
            aria-label="메뉴 닫기"
          />

          {/* 패널 */}
          <div className="absolute left-0 top-0 h-full w-72 bg-background border-r shadow-lg p-2">
            <div className="h-14 px-2 flex items-center justify-between border-b">
              <NavLink
                to="/dashboard"
                className="font-semibold text-sm"
                onClick={onMobileClose}
              >
                스톡앤메이크
              </NavLink>

              <Button variant="ghost" size="icon" onClick={onMobileClose} aria-label="닫기">
                <X className="h-5 w-5" />
              </Button>
            </div>

            <nav className="p-2 space-y-1">
              {items.map((it) => (
                <NavLink
                  key={it.to}
                  to={it.to}
                  onClick={onMobileClose}
                  className={({ isActive }) => linkClass(isActive)}
                >
                  {it.label}
                </NavLink>
              ))}
            </nav>
          </div>
        </div>
      ) : null}
    </>
  )
}
