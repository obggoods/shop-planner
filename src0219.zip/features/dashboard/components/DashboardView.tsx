// src/features/dashboard/components/DashboardView.tsx
import { useCallback, useMemo, useRef, useState } from "react"
import { upsertInventoryItemDB } from "@/data/store.supabase"
import { useAppData } from "@/features/core/useAppData"
import { toast } from "@/lib/toast"
import { AppButton } from "@/components/app/AppButton"
import { AppCard } from "@/components/app/AppCard"
import { AppSelect } from "@/components/app/AppSelect"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

import { EmptyState } from "@/components/shared/EmptyState"
import { ErrorState } from "@/components/shared/ErrorState"
import { Skeleton } from "@/components/shared/Skeleton"

function num(n: unknown, fallback = 0) {
  const v = typeof n === "number" ? n : Number(n)
  return Number.isFinite(v) ? v : fallback
}

function toKey(v: unknown) {
  return String(v ?? "")
}

function safeFilename(name: string) {
  return String(name ?? "").replace(/[\\\/:*?"<>|]/g, "_").trim()
}

function downloadCSV(filename: string, rows: string[][]) {
  const csvContent = rows
    .map((r) => r.map((v) => `"${String(v).replace(/"/g, '""')}"`).join(","))
    .join("\n")

  const BOM = "\uFEFF"
  const blob = new Blob([BOM + csvContent], { type: "text/csv;charset=utf-8;" })
  const url = URL.createObjectURL(blob)

  const a = document.createElement("a")
  a.href = url
  a.download = filename
  a.click()
  URL.revokeObjectURL(url)
}

function DashboardViewInner() {
  const a = useAppData()
  const data = a.data
  // 이번 달 기준
const now = new Date()
const currentMonth = `${now.getFullYear()}-${String(
  now.getMonth() + 1
).padStart(2, "0")}`

// settlements 데이터가 AppData에 없으면
// 나중에 loadMonthlySettlementSummary()로 대체 가능

const monthlySettlements = a.data.settlements.filter((s) => s.month === currentMonth)
const productById = useMemo(() => {
  const m = new Map<string, any>()
  for (const p of data.products) m.set(p.id, p)
  return m
}, [a.data.products])

let totalGross = 0
let totalNet = 0
let totalSold = 0

for (const s of monthlySettlements) {
  const store = a.data.stores.find((st) => st.id === s.storeId)
  const commissionRate = (store?.commissionRate ?? 0) / 100 // ✅ 너는 %로 저장(예: 25)이라서 /100 필요

  for (const item of s.items) {
    const price = productById.get(item.productId)?.price ?? 0
const gross = item.soldQty * price
    totalGross += gross
    totalNet += gross * (1 - commissionRate)
    totalSold += item.soldQty
  }
}
  
  const loading = a.loading
  const errorMsg = a.errorMsg

  const stores = data.stores ?? []
  const products = data.products ?? []
  const inventory = data.inventory ?? [] // { storeId, productId, onHandQty }

  const [selectedStoreId, setSelectedStoreId] = useState<string>("__all__")

  const storeOptions = useMemo(() => {
    const base = [{ label: "전체", value: "__all__" }]
    const mapped = stores
      .map((s: any) => ({ label: String(s?.name ?? "입점처"), value: String(s?.id ?? "") }))
      .filter((x) => x.value)
    return [...base, ...mapped]
  }, [stores])

  const targetQty = useMemo(() => {
    const v = Number.parseInt(String(a.defaultTargetQtyInput ?? "5").trim(), 10)
    return Number.isFinite(v) ? Math.max(0, v) : 5
  }, [a.defaultTargetQtyInput])

  const storeById = useMemo(
    () => new Map<string, any>(stores.map((s: any) => [String(s.id), s])),
    [stores]
  )
  
  // ✅ override 반영한 실제 목표 재고
  const effectiveTargetQty = useMemo(() => {
    if (selectedStoreId === "__all__") return targetQty
  
    const store = storeById.get(String(selectedStoreId))
    const override = Number(store?.targetQtyOverride)
  
    if (Number.isFinite(override) && override > 0) return override
    return targetQty
  }, [selectedStoreId, storeById, targetQty])
  
  // ✅ override 적용 여부(표시용)
  const isTargetOverrideActive = useMemo(() => {
    if (selectedStoreId === "__all__") return false
  
    const store = storeById.get(String(selectedStoreId))
    const override = Number(store?.targetQtyOverride)
  
    return Number.isFinite(override) && override > 0 && override !== targetQty
  }, [selectedStoreId, storeById, targetQty])
  
  // ✅ 화면에 표시할 목표재고 라벨
  const targetQtyLabel = useMemo(() => {
    if (selectedStoreId === "__all__") return `${effectiveTargetQty}`
    return isTargetOverrideActive
      ? `${effectiveTargetQty} (override)`
      : `${effectiveTargetQty}`
  }, [selectedStoreId, effectiveTargetQty, isTargetOverrideActive])  
  
  const productNameById = useMemo(() => {
    const m = new Map<string, string>()
    for (const p of products as any[]) {
      m.set(String(p.id), String(p.name ?? "제품"))
    }
    return m
  }, [products])

  const lowStockThreshold = useMemo(() => {
    const v = Number.parseInt(String(a.lowStockThresholdInput ?? "2").trim(), 10)
    return Number.isFinite(v) ? Math.max(0, v) : 2
  }, [a.lowStockThresholdInput])



  const filteredInventory = useMemo(() => {
    if (selectedStoreId === "__all__") return inventory
    return inventory.filter((it: any) => String(it.storeId) === selectedStoreId)
  }, [inventory, selectedStoreId])

  const qtyInputRefs = useRef<Array<HTMLInputElement | null>>([])

  // KPI
  const totalSku = useMemo(() => products.length, [products])

  const lowStockCount = useMemo(() => {
    return filteredInventory.filter((it: any) => num(it.onHandQty, 0) < lowStockThreshold).length
  }, [filteredInventory, lowStockThreshold])

  const storeCount = useMemo(() => (selectedStoreId === "__all__" ? stores.length : 1), [stores.length, selectedStoreId])

  // 제작 필요: 목표 대비 부족분 합
  const makeNeededTotal = useMemo(() => {
    return filteredInventory.reduce((acc: number, it: any) => {
      const onHand = num(it.onHandQty, 0)
      return acc + Math.max(0, effectiveTargetQty - onHand)
    }, 0)
  }, [filteredInventory, effectiveTargetQty])

  // 테이블용
  const [onlyLowStock, setOnlyLowStock] = useState(false)
  const inventoryRows = useMemo(() => {
    const base = filteredInventory
    if (!onlyLowStock) return base
    return base.filter((it: any) => num(it.onHandQty, 0) < lowStockThreshold)
  }, [filteredInventory, onlyLowStock, lowStockThreshold])

  const setQtyLocal = useCallback(
    (storeId: string, productId: string, nextQty: number) => {
      a.setData((prev) => {
        const inv = prev.inventory ?? []
        const idx = inv.findIndex((x: any) => x.storeId === storeId && x.productId === productId)
  
        const nextInv =
          idx >= 0
            ? inv.map((x: any, i: number) =>
                i === idx ? { ...x, onHandQty: nextQty, updatedAt: Date.now() } : x
              )
            : [{ storeId, productId, onHandQty: nextQty, updatedAt: Date.now() }, ...inv]
  
        return { ...prev, inventory: nextInv, updatedAt: Date.now() }
      })
    },
    [a]
  )  
  const saveTimersRef = useRef<Record<string, number>>({})

const scheduleSaveQty = useCallback(
  (storeId: string, productId: string, nextQty: number) => {
    const key = `${storeId}__${productId}`

    const prevTimer = saveTimersRef.current[key]
    if (prevTimer) window.clearTimeout(prevTimer)

    saveTimersRef.current[key] = window.setTimeout(async () => {
      try {
        await upsertInventoryItemDB({ storeId, productId, onHandQty: nextQty })
      } catch (e) {
        console.error(e)
        toast.error("재고 저장에 실패했어요.")
        await a.refresh()
      }
    }, 500)
  },
  [a]
)

// ✅ Enter/↑/↓로 이동 (값 증감은 막고 포커스 이동만)
const moveFocus = useCallback((fromIndex: number, dir: -1 | 1) => {
  const next = fromIndex + dir
  const el = qtyInputRefs.current[next]
  if (el) el.focus()
}, [])

  // 제작 리스트(need 큰 순)
  const makeRows = useMemo(() => {
    return filteredInventory
      .map((it: any) => {
        const onHand = num(it.onHandQty, 0)
        const need = Math.max(0, effectiveTargetQty - onHand)
        return { it, need }
      })
      .filter((x) => x.need > 0)
      .sort((a, b) => b.need - a.need)
  }, [filteredInventory, effectiveTargetQty])

  // 다운로드
  const exportInventoryCSV = useCallback(() => {
    const today = new Date().toISOString().slice(0, 10)
    const store = selectedStoreId === "__all__" ? null : storeById.get(String(selectedStoreId))

    const rows: string[][] = []
    rows.push(["입점처", "제품", "현재 재고"])

    for (const it of inventoryRows as any[]) {
      const sName =
        selectedStoreId === "__all__"
          ? storeById.get(String(it.storeId))?.name ?? "-"
          : store?.name ?? "-"
      const pName = productNameById.get(String(it.productId)) ?? "제품"
      rows.push([String(sName), String(pName), String(it.onHandQty ?? 0)])
    }

    const storeSafe = safeFilename(store?.name ?? "전체")
    downloadCSV(`ShopPlanner_재고현황_${storeSafe}_${today}.csv`, rows)
  }, [inventoryRows, productNameById, selectedStoreId, storeById])

  const exportMakeCSV = useCallback(() => {
    const today = new Date().toISOString().slice(0, 10)
    const store = selectedStoreId === "__all__" ? null : storeById.get(String(selectedStoreId))

    const rows: string[][] = []
    rows.push(["입점처", "제품", "현재 재고", "목표 재고", "필요 수량"])

    for (const { it, need } of makeRows as any[]) {
      const onHand = num(it.onHandQty, 0)
      const sName =
        selectedStoreId === "__all__"
          ? storeById.get(String(it.storeId))?.name ?? "-"
          : store?.name ?? "-"
      const pName = productNameById.get(String(it.productId)) ?? "제품"
      rows.push([String(sName), String(pName), String(onHand), String(effectiveTargetQty), String(need)])
    }

    const storeSafe = safeFilename(store?.name ?? "전체")
    downloadCSV(`ShopPlanner_제작리스트_${storeSafe}_${today}.csv`, rows)
  }, [makeRows, productNameById, selectedStoreId, storeById, effectiveTargetQty])

  // 탭: 기본을 재고 현황으로
  const [tab, setTab] = useState<"inventory" | "make">("inventory")

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-10 w-[240px]" />
        <div className="grid gap-3 sm:grid-cols-3">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
        <Skeleton className="h-80" />
      </div>
    )
  }

  if (errorMsg) {
    return <ErrorState title="대시보드를 불러오지 못했습니다." message={String(errorMsg)} />
  }

  return (
    <div className="space-y-4">
      {/* 상단 컨트롤: (중복 제목 제거) */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div className="w-full sm:w-[240px]">
          <AppSelect
            value={selectedStoreId}
            onValueChange={(v: string) => setSelectedStoreId(v)}
            options={storeOptions as any}
          />
        </div>

        <div className="flex gap-2">
          <AppButton variant="secondary" onClick={exportInventoryCSV}>
            재고 현황 다운로드
          </AppButton>
          <AppButton variant="secondary" onClick={exportMakeCSV}>
            제작 리스트 다운로드
          </AppButton>
        </div>
      </div>

      {/* KPI 3개 */}
      <div className="grid gap-3 sm:grid-cols-3">
        <AppCard className="shadow-sm">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">총 SKU</p>
            <p className="text-3xl font-semibold tabular-nums">{totalSku}</p>
          </div>
        </AppCard>

        <AppCard className="shadow-sm">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">저재고 SKU</p>
            <p className="text-3xl font-semibold tabular-nums">{lowStockCount}</p>
            <button
              type="button"
              onClick={() => {
                setOnlyLowStock(true)
                setTab("inventory")
              }}
              className="text-xs text-muted-foreground underline underline-offset-4"
            >
              저재고만 보기
            </button>
          </div>
        </AppCard>

        <AppCard className="shadow-sm">
          <div className="space-y-1">
            <p className="text-sm text-muted-foreground">입점처 수</p>
            <p className="text-3xl font-semibold tabular-nums">{storeCount}</p>
          </div>
        </AppCard>
      </div>

      {/* 핵심: 입점처별 재고 현황을 바로 */}
      <AppCard className="shadow-sm">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
          <div className="space-y-1">
            <p className="text-sm font-medium">입점처별 재고 현황</p>
            <p className="text-xs text-muted-foreground">
            기준: 저재고 &lt; {lowStockThreshold} / 목표 재고 {targetQtyLabel}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <AppButton
              variant={onlyLowStock ? "default" : "secondary"}
              onClick={() => setOnlyLowStock((v) => !v)}
            >
              {onlyLowStock ? "저재고 필터 ON" : "저재고 필터 OFF"}
            </AppButton>
          </div>
        </div>

        {/* 하단 탭: 재고/제작 */}
        <div className="mt-3">
          <Tabs value={tab} onValueChange={(v) => setTab(v as any)} className="w-full">
            <TabsList className="w-full justify-start">
              <TabsTrigger value="inventory">재고 현황</TabsTrigger>
              <TabsTrigger value="make">제작 리스트</TabsTrigger>
            </TabsList>

            {/* 재고 테이블 */}
            <TabsContent value="inventory" className="mt-3">
              <div className="overflow-hidden rounded-lg border">
                <Table className="w-full text-sm">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[52%]">제품</TableHead>
                      <TableHead className="w-[28%]">입점처</TableHead>
                      <TableHead className="w-[20%] text-right">현재</TableHead>
                    </TableRow>
                  </TableHeader>

                  <TableBody>
                    {inventoryRows.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="py-10">
                          <EmptyState title="표시할 데이터가 없습니다." description="입점처/필터를 확인해 주세요." />
                        </TableCell>
                      </TableRow>
                    ) : (
                      inventoryRows.map((it: any, rowIndex: number) => {
                        const pName = productNameById.get(String(it.productId)) ?? "제품"
                        const sName = storeById.get(String(it.storeId))?.name ?? "-"
                        const current = num(it.onHandQty, 0)
                        const isLow = current < lowStockThreshold

                        // ✅ “저재고 배지 제거” 대신 행 배경 연한 붉은색
                        const rowClass = isLow ? "bg-destructive/10" : "hover:bg-accent/30"

                        return (
                          <TableRow key={toKey(`${it.storeId}-${it.productId}`)} className={rowClass}>
                            <TableCell className="font-medium">{pName}</TableCell>
                            <TableCell className="text-muted-foreground">{sName}</TableCell>
                            <TableCell className="text-right">
                            <input
  ref={(el) => {
    qtyInputRefs.current[rowIndex] = el
  }}
  type="number"
  inputMode="numeric"
  className="h-9 w-[92px] rounded-md border bg-background px-2 text-right tabular-nums focus:outline-none focus:ring-2 focus:ring-ring"
  value={current}
  onChange={(e) => {
    const v = Number(e.target.value)
    const nextQty = Number.isFinite(v) ? Math.max(0, Math.floor(v)) : 0

    // ✅ 1) 즉시 화면 반영
    setQtyLocal(String(it.storeId), String(it.productId), nextQty)

    // ✅ 2) 500ms 후 자동 저장(입력 멈추면 저장)
    scheduleSaveQty(String(it.storeId), String(it.productId), nextQty)
  }}
  onBlur={(e) => {
    const v = Number((e.target as HTMLInputElement).value)
    const nextQty = Number.isFinite(v) ? Math.max(0, Math.floor(v)) : 0
    setQtyLocal(String(it.storeId), String(it.productId), nextQty)
    scheduleSaveQty(String(it.storeId), String(it.productId), nextQty)
  }}
  onKeyDown={(e) => {
    if (e.key === "Enter" || e.key === "ArrowDown") {
      e.preventDefault()
      moveFocus(rowIndex, 1)
    }
    if (e.key === "ArrowUp") {
      e.preventDefault()
      moveFocus(rowIndex, -1)
    }
  }}
  onFocus={(e) => {
    ;(e.target as HTMLInputElement).select()
  }}
/>

</TableCell>
                          </TableRow>
                        )
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>

            {/* 제작 리스트 테이블 */}
            <TabsContent value="make" className="mt-3">
              <div className="flex items-center justify-between">
                <div className="text-xs text-muted-foreground">
                  제작 필요 합계: <span className="font-semibold tabular-nums">{makeNeededTotal}</span>
                </div>
              </div>

              <div className="mt-2 overflow-hidden rounded-lg border">
                <Table className="w-full text-sm">
                  <TableHeader>
                    <TableRow>
                      <TableHead className="w-[52%]">제품</TableHead>
                      <TableHead className="w-[28%]">입점처</TableHead>
                      <TableHead className="w-[20%] text-right">필요</TableHead>
                    </TableRow>
                  </TableHeader>

                  <TableBody>
                    {makeRows.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="py-10">
                          <EmptyState title="제작 필요 항목이 없습니다." description="현재는 안정적인 상태입니다." />
                        </TableCell>
                      </TableRow>
                    ) : (
                      makeRows.slice(0, 50).map(({ it, need }: any) => {
                        const pName = productNameById.get(String(it.productId)) ?? "제품"
                        const sName = storeById.get(String(it.storeId))?.name ?? "-"
                        return (
                          <TableRow key={toKey(`${it.storeId}-${it.productId}`)} className="hover:bg-accent/30">
                            <TableCell className="font-medium">{pName}</TableCell>
                            <TableCell className="text-muted-foreground">{sName}</TableCell>
                            <TableCell className="text-right tabular-nums">
                              <span className="font-semibold">{need}</span>
                            </TableCell>
                          </TableRow>
                        )
                      })
                    )}
                  </TableBody>
                </Table>
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </AppCard>
    </div>
  )
}

/**
 * import 형태가 섞여 있어도 깨지지 않게 둘 다 제공
 */
export const DashboardView = DashboardViewInner
export default DashboardViewInner
