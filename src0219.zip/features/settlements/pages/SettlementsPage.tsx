import { useEffect, useMemo, useState } from "react"

import PageHeader from "@/app/layout/PageHeader"
import SettlementUploader from "@/features/settlements/components/SettlementUploader"

import { AppCard } from "@/components/app/AppCard"
import { AppBadge } from "@/components/app/AppBadge"
import { AppButton } from "@/components/app/AppButton"

import { Skeleton } from "@/components/shared/Skeleton"
import { ErrorState } from "@/components/shared/ErrorState"

import { useAppData } from "@/features/core/useAppData"
import { listSettlementsDB, getSettlementDetailDB } from "@/data/store.supabase"

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"

function monthOptions(n = 24) {
  return Array.from({ length: n }).map((_, i) => {
    const d = new Date()
    d.setMonth(d.getMonth() - i)
    const y = d.getFullYear()
    const m = String(d.getMonth() + 1).padStart(2, "0")
    return { value: `${y}-${m}`, label: `${y}.${m}` }
  })
}

export default function SettlementsPage() {
  const a = useAppData()

  // 조회 필터
  const [month, setMonth] = useState<string>(() => monthOptions(1)[0].value)
  const [storeId, setStoreId] = useState<string>("") // "" = 전체

  // 목록/상세
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string>("")
  const [items, setItems] = useState<any[]>([])
  const [selectedId, setSelectedId] = useState<string>("")
  const [detail, setDetail] = useState<{ settlement: any; lines: any[] } | null>(null)

  const stores = a.data.stores as any[]

  const storeNameById = useMemo(() => {
    const m = new Map<string, string>()
    for (const s of stores) m.set(s.id, s.name)
    return m
  }, [stores])

  const load = async () => {
    try {
      setLoading(true)
      setError("")
      setDetail(null)
      setSelectedId("")

      const list = await listSettlementsDB({
        marketplaceId: storeId || undefined,
        periodMonth: month || undefined,
      })
      setItems(list)
    } catch (e: any) {
      setError(e?.message ?? String(e))
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    load()
  }, [month, storeId])

  const openDetail = async (settlementId: string) => {
    try {
      setSelectedId(settlementId)
      const d = await getSettlementDetailDB({ settlementId })
      setDetail(d)
    } catch (e: any) {
      setError(e?.message ?? String(e))
    }
  }

  if (a.errorMsg) return <ErrorState message={a.errorMsg} onRetry={a.refresh} />

  return (
    <div className="space-y-6">
      <PageHeader
        title="정산"
        description="입점처 정산 CSV를 업로드하면 판매 수량이 반영되고, (선택 시) 재고가 자동으로 차감됩니다."
      />

      {/* 업로드 */}
      <SettlementUploader />

      {/* 저장된 정산(v2) 조회 */}
      <AppCard
        density="compact"
        title="저장된 정산(v2)"
        description="월/입점처별로 저장된 정산을 확인할 수 있어요."
        action={
          <div className="flex flex-wrap items-center gap-2">
            <select
              className="h-9 rounded-md border bg-background px-2 text-sm"
              value={month}
              onChange={(e) => setMonth(e.target.value)}
            >
              {monthOptions(24).map((m) => (
                <option key={m.value} value={m.value}>
                  {m.label}
                </option>
              ))}
            </select>

            <select
              className="h-9 rounded-md border bg-background px-2 text-sm"
              value={storeId}
              onChange={(e) => setStoreId(e.target.value)}
            >
              <option value="">전체 입점처</option>
              {stores.map((s: any) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>

            <AppButton type="button" variant="outline" onClick={load} disabled={loading}>
              새로고침
            </AppButton>
          </div>
        }
        contentClassName="px-4 pb-4"
      >
        {loading ? <Skeleton className="h-24" /> : null}
        {error ? <ErrorState message={error} onRetry={load} /> : null}

        <div className="mt-3 rounded-xl border overflow-hidden">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[140px]">입점처</TableHead>
                <TableHead className="w-[90px]">월</TableHead>
                <TableHead className="w-[120px] text-right">총매출</TableHead>
                <TableHead className="w-[120px] text-right">수수료</TableHead>
                <TableHead className="w-[120px] text-right">정산금</TableHead>
                <TableHead className="w-[90px]">상태</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {items.map((s: any) => (
                <TableRow
                  key={s.id}
                  className={selectedId === s.id ? "bg-muted/30" : undefined}
                  onClick={() => openDetail(s.id)}
                >
                  <TableCell className="truncate">
                    {storeNameById.get(s.marketplace_id) ?? "-"}
                  </TableCell>
                  <TableCell>{s.period_month}</TableCell>
                  <TableCell className="text-right tabular-nums">
                    {Number(s.gross_amount ?? 0).toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {Number(s.commission_amount ?? 0).toLocaleString()}
                  </TableCell>
                  <TableCell className="text-right tabular-nums">
                    {Number(s.net_amount ?? 0).toLocaleString()}
                  </TableCell>
                  <TableCell>
                    <AppBadge variant={s.status === "confirmed" ? "default" : "secondary"}>
                      {s.status}
                    </AppBadge>
                  </TableCell>
                </TableRow>
              ))}

              {items.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={6} className="text-sm text-muted-foreground">
                    저장된 정산이 없습니다.
                  </TableCell>
                </TableRow>
              ) : null}
            </TableBody>
          </Table>
        </div>

        {detail ? (
          <div className="mt-4 space-y-2">
            <div className="text-sm font-medium">정산 상세</div>

            <div className="rounded-xl border overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>상품</TableHead>
                    <TableHead className="w-[90px] text-right">판매</TableHead>
                    <TableHead className="w-[110px] text-right">단가</TableHead>
                    <TableHead className="w-[120px] text-right">매출</TableHead>
                    <TableHead className="w-[90px]">매칭</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {detail.lines.map((l: any) => (
                    <TableRow key={l.id}>
                      <TableCell className="truncate">
                        {l.product_name_matched ?? l.product_name_raw}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {Number(l.qty_sold ?? 0).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {Number(l.unit_price ?? 0).toLocaleString()}
                      </TableCell>
                      <TableCell className="text-right tabular-nums">
                        {Number(l.gross_amount ?? 0).toLocaleString()}
                      </TableCell>
                      <TableCell>{l.match_status}</TableCell>
                    </TableRow>
                  ))}

                  {detail.lines.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={5} className="text-sm text-muted-foreground">
                        라인이 없습니다.
                      </TableCell>
                    </TableRow>
                  ) : null}
                </TableBody>
              </Table>
            </div>
          </div>
        ) : null}
      </AppCard>
    </div>
  )
}
